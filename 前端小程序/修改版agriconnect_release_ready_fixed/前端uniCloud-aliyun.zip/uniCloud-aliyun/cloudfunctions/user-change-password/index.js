// 修改密码云函数（需登录态）
// 调用方式：uniCloud.callFunction({ name: 'user-change-password', data: { oldPassword, newPassword, token } })

'use strict';

const bcrypt = require('bcryptjs');
const { verifyToken, createResponse } = require('./common/authHelper');

exports.main = async (event, context) => {
  const db = uniCloud.database();
  const usersCollection = db.collection('uni-id-users');

  const { oldPassword, newPassword, token } = event;

  const res = (code, message, data) => {
    return { code, message, data: data || null };
  };

  try {
    if (!oldPassword || !newPassword) {
      return res(400, '参数错误：oldPassword 和 newPassword 为必填项');
    }

    if (typeof newPassword !== 'string' || newPassword.length < 6) {
      return res(400, '新密码格式不符合要求：长度需不小于6位');
    }

    // 验证 token 并获取 userId
    const tokenResult = verifyToken(event);
    if (!tokenResult.success) {
      return res(401, tokenResult.error || '未登录或登录已过期');
    }

    const userId = tokenResult.userId;

    // 查询当前用户
    const userRes = await usersCollection
      .doc(userId)
      .get();

    if (!userRes.data) {
      return res(400, '用户不存在');
    }

    const user = userRes.data;

    if (user.status !== 0) {
      return res(400, '账号已被禁用');
    }

    // 校验旧密码
    const matchOld = await bcrypt.compare(oldPassword, user.password);
    if (!matchOld) {
      return res(400, '旧密码错误');
    }

    // 加密新密码
    const newHash = await bcrypt.hash(newPassword, 10);

    // 更新密码，可选：同时增加 token_version 字段，让旧 token 失效
    await usersCollection
      .doc(userId)
      .update({
        password: newHash
      });

    return res(200, '密码修改成功');
  } catch (err) {
    console.error('user-change-password error:', err);
    return res(500, '服务器内部错误', { error: err.message });
  }
};

