// 绑定手机号云函数
// 调用方式：uniCloud.callFunction({ name: 'bindPhoneNumber', data: { phoneCode } })
// 
// 功能：
// 1. 验证 token 获取当前用户
// 2. 使用 phoneCode 调用微信接口获取手机号
// 3. 更新用户手机号

'use strict';
const { verifyToken } = require('./common/authHelper');

// 统一返回方法
const res = (code, message, data) => {
  return { code, message, data: data || null };
};

/**
 * 获取微信小程序 access_token（带缓存）
 */
let accessTokenCache = {
  token: null,
  expiresAt: 0
};

async function getAccessToken() {
  const now = Date.now();
  
  if (accessTokenCache.token && accessTokenCache.expiresAt > now) {
    return accessTokenCache.token;
  }

  // 使用统一的配置读取函数（使用自包含版本）
  const getWechatConfig = require('./common/getWechatConfig');
  let appid, secret;
  
  try {
    const config = getWechatConfig();
    appid = config.appid;
    secret = config.secret;
    console.log('[bindPhoneNumber] 配置读取成功');
  } catch (e) {
    console.error('[bindPhoneNumber] 配置读取失败:', e.message);
    throw e;
  }
  
  const response = await uniCloud.httpclient.request('https://api.weixin.qq.com/cgi-bin/token', {
    method: 'GET',
    data: {
      grant_type: 'client_credential',
      appid: appid,
      secret: secret
    },
    dataType: 'json'
  });

  if (response.status !== 200 || !response.data || response.data.errcode) {
    throw new Error(response.data?.errmsg || '获取 access_token 失败');
  }

  const { access_token, expires_in } = response.data;
  
  accessTokenCache = {
    token: access_token,
    expiresAt: now + (expires_in - 300) * 1000
  };

  return access_token;
}

/**
 * 获取用户手机号
 */
async function getPhoneNumber(phoneCode) {
  const accessToken = await getAccessToken();
  
  const response = await uniCloud.httpclient.request(`https://api.weixin.qq.com/wxa/business/getuserphonenumber?access_token=${accessToken}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    data: {
      code: phoneCode
    },
    dataType: 'json'
  });

  if (response.status !== 200 || !response.data || response.data.errcode) {
    throw new Error(response.data?.errmsg || '获取手机号失败');
  }

  return response.data.phone_info?.phoneNumber || response.data.phone_info?.purePhoneNumber;
}

exports.main = async (event, context) => {
  const db = uniCloud.database();
  const usersCollection = db.collection('uni-id-users');

  const { phoneCode } = event;

  try {
    // 参数校验
    if (!phoneCode) {
      return res(400, '参数错误：phoneCode 为必填项');
    }

    // 验证 token 获取当前用户
    const tokenResult = verifyToken(event);
    if (!tokenResult.success) {
      return res(401, tokenResult.error || '登录状态无效');
    }
    const userId = tokenResult.userId;

    // 获取手机号
    const phoneNumber = await getPhoneNumber(phoneCode);

    if (!phoneNumber) {
      return res(400, '获取手机号失败');
    }

    // 检查手机号是否已被其他用户使用
    const existingUser = await usersCollection
      .where({
        mobile: phoneNumber,
        _id: db.command.neq(userId)
      })
      .limit(1)
      .get();

    if (existingUser.data && existingUser.data.length > 0) {
      return res(400, '该手机号已被其他账号绑定');
    }

    // 更新用户手机号
    await usersCollection.doc(userId).update({
      mobile: phoneNumber
    });

    return res(200, '绑定成功', {
      phoneNumber: phoneNumber
    });

  } catch (err) {
    console.error('[bindPhoneNumber] 错误:', err);
    return res(500, err.message || '服务器内部错误');
  }
};
