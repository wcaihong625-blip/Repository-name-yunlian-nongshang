// 统一身份验证工具模块
// 读取顺序：
// 1. 环境变量 JWT_SECRET / JWT_EXPIRES_IN
// 2. uni-config-center/wechat-login/config.json 中的 jwt 配置
// 3. 兼容 common/config.json

'use strict';

const jwt = require('jsonwebtoken');

function getCurrentEnv() {
  let env = process.env.UNI_PLATFORM_ENV || process.env.NODE_ENV;

  if (process.env.UNI_CLOUD_PROVIDER) {
    env = 'production';
    if (
      process.env.UNI_CLOUD_HBUILDERX_DEBUG === 'true' ||
      process.env.NODE_ENV === 'development'
    ) {
      env = 'development';
    }
  }

  return env || 'production';
}

function loadJwtConfig() {
  let secret = process.env.JWT_SECRET || '';
  let expiresIn = process.env.JWT_EXPIRES_IN || '';

  if (secret) {
    console.log('[authHelper] 已从环境变量读取 JWT 配置', {
      hasSecret: true,
      expiresIn: expiresIn || '7d'
    });
    return {
      secret,
      expiresIn: expiresIn || '7d'
    };
  }

  const possiblePaths = [
    './uni-config-center/index.js',
    '../common/uni-config-center/index.js',
    '../../common/uni-config-center/index.js'
  ];
  const pluginIds = ['wechat-login', 'common'];
  const env = getCurrentEnv();

  for (const configPath of possiblePaths) {
    for (const pluginId of pluginIds) {
      try {
        const createConfig = require(configPath);
        const configCenter = createConfig({ pluginId });
        const rawConfig =
          typeof configCenter.rawConfig === 'function'
            ? configCenter.rawConfig()
            : null;
        const envConfig =
          (rawConfig && (rawConfig[env] || rawConfig.production || rawConfig.development)) ||
          (typeof configCenter.config === 'function' ? configCenter.config() : null) ||
          {};

        if (!secret && envConfig?.jwt?.secret) {
          secret = envConfig.jwt.secret;
        }
        if (!expiresIn && envConfig?.jwt?.expiresIn) {
          expiresIn = envConfig.jwt.expiresIn;
        }

        if (secret) {
          console.log('[authHelper] 已从配置文件读取 JWT 配置', {
            env,
            pluginId,
            configPath,
            hasSecret: true,
            expiresIn: expiresIn || '7d'
          });
          return {
            secret,
            expiresIn: expiresIn || '7d'
          };
        }
      } catch (error) {
        // 继续尝试下一个路径
      }
    }
  }

  return {
    secret,
    expiresIn: expiresIn || '7d'
  };
}

const runtimeEnv = getCurrentEnv();
const isDevelopment = runtimeEnv === 'development';
const jwtConfig = loadJwtConfig();
let JWT_SECRET = jwtConfig.secret;
const JWT_EXPIRES_IN = jwtConfig.expiresIn || '7d';

if (!JWT_SECRET) {
  if (!isDevelopment) {
    throw new Error(
      '[authHelper] 生产环境缺少 JWT_SECRET。请在 uniCloud-aliyun/cloudfunctions/common/uni-config-center/wechat-login/config.json 中配置 jwt.secret，或在云函数环境变量中配置 JWT_SECRET。'
    );
  }

  console.warn(
    '[authHelper] 开发环境未配置 JWT_SECRET，暂时使用默认调试密钥。正式发布前请务必改成你自己的强密码。'
  );
  JWT_SECRET = 'PLEASE_REPLACE_WITH_STRONG_SECRET_FOR_DEVELOPMENT_ONLY';
}

console.log('[authHelper] JWT 配置已加载', {
  env: runtimeEnv,
  hasSecret: !!JWT_SECRET,
  expiresIn: JWT_EXPIRES_IN
});

/**
 * 签发 JWT token
 * @param {Object} payload token 载荷
 * @param {string} expiresIn 过期时间，默认使用配置值
 * @returns {string}
 */
function signToken(payload, expiresIn = JWT_EXPIRES_IN) {
  if (!JWT_SECRET) {
    throw new Error('[authHelper] JWT_SECRET 未配置，无法签发 token');
  }
  return jwt.sign(payload, JWT_SECRET, { expiresIn });
}

/**
 * 验证 token 并获取用户 ID
 * @param {Object} event 云函数事件对象
 * @returns {Object}
 */
function verifyToken(event) {
  let token =
    event.uniIdToken ||
    event.token ||
    event.authorization ||
    (event.headers && (event.headers.authorization || event.headers.Authorization));

  if (!token) {
    console.log('[authHelper] receive empty token, rejected');
    return {
      success: false,
      userId: null,
      error: '未登录，请先登录'
    };
  }

  // 1. 记录收到 token 时的状态信息
  console.log('[authHelper] bindPhoneNumber / verifyToken 收到 token:');
  console.log(' - 是否有 token:', !!token);
  console.log(' - token 前10位:', typeof token === 'string' ? token.substring(0, 10) : '未知');
  console.log(' - token 长度:', typeof token === 'string' ? token.length : 0);
  console.log(' - 当前使用的 JWT 配置来源: ' + (getCurrentEnv() === 'development' ? 'dev配置' : 'prod配置'));

  try {
    // 兼容 Bearer 和纯 token
    if (typeof token === 'string') {
        token = token.replace(/^Bearer\s+/i, '').trim();
    }
    const decoded = jwt.verify(token, JWT_SECRET);

    if (!decoded || !decoded.uid) {
      console.log(' - 当前是否成功解析 uid: 否 (无 uid 字段)');
      return {
        success: false,
        userId: null,
        error: '登录状态无效'
      };
    }

    console.log(' - 当前是否成功解析 uid: 是, uid=', decoded.uid);
    return {
      success: true,
      userId: decoded.uid,
      error: null
    };
  } catch (err) {
    // 3. jwt.verify 失败时，打印 err.name 和 err.message
    console.log(' - 当前是否成功解析 uid: 否');
    console.log('[authHelper] jwt.verify 失败:', err.name, err.message);
    
    if (err.name === 'TokenExpiredError') {
      return {
        success: false,
        userId: null,
        error: '登录状态已过期，请重新登录'
      };
    }

    if (err.name === 'JsonWebTokenError') {
      return {
        success: false,
        userId: null,
        error: '登录状态无效'
      };
    }

    return {
      success: false,
      userId: null,
      error: '验证登录状态时发生错误'
    };
  }
}

/**
 * 验证用户权限（确保用户只能操作自己的数据）
 * @param {Object} event 云函数事件对象
 * @param {string} targetUserId 目标用户 ID
 * @returns {Object}
 */
function verifyUserPermission(event, targetUserId = null) {
  const tokenResult = verifyToken(event);

  if (!tokenResult.success) {
    return tokenResult;
  }

  const authenticatedUserId = tokenResult.userId;

  if (targetUserId && targetUserId !== authenticatedUserId) {
    return {
      success: false,
      userId: authenticatedUserId,
      error: '无权访问该数据'
    };
  }

  return {
    success: true,
    userId: authenticatedUserId,
    error: null
  };
}

/**
 * 统一响应格式
 * @param {number} code 状态码
 * @param {string} message 消息
 * @param {*} data 数据
 * @returns {Object}
 */
function createResponse(code, message, data = null) {
  return {
    code,
    message,
    data
  };
}

module.exports = {
  signToken,
  verifyToken,
  verifyUserPermission,
  createResponse,
  JWT_SECRET,
  JWT_EXPIRES_IN
};
