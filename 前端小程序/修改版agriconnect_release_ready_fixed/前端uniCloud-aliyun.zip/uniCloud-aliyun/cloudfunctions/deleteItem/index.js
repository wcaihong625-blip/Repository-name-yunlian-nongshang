// 删除供应/采购信息云函数
// 调用方式：uniCloud.callFunction({ name: 'deleteItem', data: { token, id, type } })
// type: 'supply' 或 'purchase'

'use strict';

const { verifyToken, createResponse } = require('./common/authHelper');

exports.main = async (event, context) => {
  const db = uniCloud.database();
  const usersCollection = db.collection('uni-id-users');
  
  const res = (code, message, data) => {
    return { code, message, data: data || null };
  };

  try {
    // 验证 token 并获取 user_id
    const tokenResult = verifyToken(event);
    if (!tokenResult.success) {
      return res(401, tokenResult.error || '未登录，请先登录');
    }
    const user_id = tokenResult.userId;

    const { id, type } = event;

    // 参数验证
    if (!id || !type) {
      return res(400, '参数错误：id、type 为必填项');
    }

    if (type !== 'supply' && type !== 'purchase') {
      return res(400, '参数错误：type 必须是 supply 或 purchase');
    }

    // 选择对应的集合
    const collection = type === 'supply' 
      ? db.collection('supply_list')
      : db.collection('purchase_list');

    // 先查询记录，验证所有权
    const itemRes = await collection.doc(id).get();
    
    if (!itemRes.data || itemRes.data.length === 0) {
      return res(404, '记录不存在');
    }

    const item = itemRes.data[0];

    // 添加调试日志
    console.log('[deleteItem] 当前用户 ID:', user_id);
    console.log('[deleteItem] 记录的 user_id:', item.user_id);
    console.log('[deleteItem] ID 类型对比:', typeof user_id, 'vs', typeof item.user_id);
    console.log('[deleteItem] 严格相等:', item.user_id === user_id);
    console.log('[deleteItem] 宽松相等:', item.user_id == user_id);

    // 验证是否为该用户发布的
    if (item.user_id !== user_id) {
      console.log('[deleteItem] 权限验证失败');
      return res(403, '无权删除此记录');
    }
    
    console.log('[deleteItem] 权限验证通过，准备删除');

    // 删除记录
    const deleteRes = await collection.doc(id).remove();

    if (deleteRes.deleted > 0) {
      // 更新用户表的统计字段
      const updateField = type === 'supply' ? 'supply_count' : 'procurement_count';
      await usersCollection.doc(user_id).update({
        [updateField]: db.command.inc(-1)
      }).catch(err => {
        console.error('更新用户统计失败:', err);
        // 不影响主流程，继续执行
      });

      return res(200, '删除成功');
    } else {
      return res(500, '删除失败，请重试');
    }
  } catch (err) {
    console.error('deleteItem error:', err);
    return res(500, '服务器内部错误', { error: err.message });
  }
};




