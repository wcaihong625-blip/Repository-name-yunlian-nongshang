'use strict';
const db = uniCloud.database(); // 初始化数据库

exports.main = async (event, context) => {
  // 1. 安全校验：验证请求是否来自你的爬虫服务器
  const SECRET_TOKEN = 'AgriData2025!@#'; // 设置一个强密码，并与爬虫脚本中的 token 保持一致
  if (event.token !== SECRET_TOKEN) {
    return {
      success: false,
      message: '无权访问',
      code: 403
    };
  }

  // 2. 解析爬虫发送过来的数据
  const { action, data } = event;
  
  // 只处理 “updateMarketData” 动作
  if (action !== 'updateMarketData') {
    return {
      success: false,
      message: '未知的操作类型',
      code: 400
    };
  }

  // 3. 简单的数据验证（根据你的数据结构加强）
  if (!data || !data.products || !Array.isArray(data.products)) {
    return {
      success: false,
      message: '数据格式错误',
      code: 400
    };
  }

  console.log(`收到爬虫数据，共 ${data.products.length} 条产品记录，时间: ${data.updateTime}`);
  
  try {
    // 4. 获取数据库集合引用（如果集合不存在会自动创建）
    const collection = db.collection('market_data');
    
    // 5. 构建要存储的文档
    const docToInsert = {
      ...data, // 包含 source, updateTime, products 等所有字段
      _createTime: Date.now() // 添加服务器时间戳
    };
    
    // 6. 将数据插入到数据库
    const res = await collection.add(docToInsert);
    
    console.log('数据写入数据库成功，文档ID:', res.id);
    
    // 7. 返回成功信息给爬虫服务器
    return {
      success: true,
      message: `成功接收并存储 ${data.products.length} 条行情数据`,
      dataId: res.id
    };
    
  } catch (err) {
    // 8. 如果出错，记录日志并返回错误
    console.error('云函数执行出错，错误信息:', err);
    return {
      success: false,
      message: '服务器内部错误，数据存储失败',
      code: 500,
      error: err.message
    };
  }
};