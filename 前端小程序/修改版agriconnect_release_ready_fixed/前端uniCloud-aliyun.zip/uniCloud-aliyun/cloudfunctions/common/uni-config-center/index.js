const path = require('path')
const fs = require('fs')

const plugName = 'uni-config-center'

module.exports = (pluginConfig) => {
	let pluginId
	if (typeof pluginConfig === 'string') {
		pluginId = pluginConfig
	} else {
		pluginId = pluginConfig.pluginId
	}
	
	if (!pluginId) {
		throw new Error('请指定pluginId')
	}

	const configDir = path.resolve(__dirname, pluginId)
	
	let config = {}
	try {
		// 尝试读取 config.json
		config = require(path.resolve(configDir, 'config.json'))
	} catch (e) {
		if (e.code !== 'MODULE_NOT_FOUND') {
			throw e
		}
		// config.json 不存在时，尝试读取 config.js
		try {
			config = require(path.resolve(configDir, 'config.js'))
		} catch (e) {
			// 都不存在时，依然返回空对象，或者根据需求抛错
			// console.warn(`[uni-config-center] ${pluginId} 配置文件不存在`)
		}
	}

	return {
		config(key) {
			// 自动识别环境
			let env = process.env.UNI_PLATFORM_ENV || process.env.NODE_ENV
			// uniCloud环境兼容
			if (process.env.UNI_CLOUD_PROVIDER) {
				// 阿里云/腾讯云环境
				env = 'production'
				// 本地运行环境
				if (process.env.UNI_CLOUD_HBUILDERX_DEBUG === 'true' || process.env.NODE_ENV === 'development') {
					env = 'development'
				}
			}
			
			// 如果没有指定 key，返回当前环境的整个配置
			if (!key) {
				return config[env] || config['default'] || config
			}
			
			// 返回指定 key 的配置
			if (config[env] && config[env][key]) {
				return config[env][key]
			}
			if (config['default'] && config['default'][key]) {
				return config['default'][key]
			}
			return config[key]
		},
		// 获取原始的完整配置
		rawConfig() {
			return config
		},
		// 兼容旧版用法，直接返回当前环境配置
		...config
	}
}

