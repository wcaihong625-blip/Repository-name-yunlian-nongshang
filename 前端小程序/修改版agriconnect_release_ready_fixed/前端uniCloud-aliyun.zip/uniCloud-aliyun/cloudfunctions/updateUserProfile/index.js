'use strict';

const { verifyToken, createResponse } = require('./common/authHelper');

/**
 * 云函数：更新用户个人信息
 * @param {String} token - JWT token（必填）
 * @param {String} avatar - 头像URL（可选）
 * @param {String} nickname - 昵称（可选）
 * @param {String} username - 用户名（可选）
 * @param {String} bio - 个人简介（可选）
 * @param {String} location - 地址（可选）
 * @param {String} industry - 行业（可选）
 */
exports.main = async (event, context) => {
    console.log('updateUserProfile 云函数被调用');
    
    // 验证 token 并获取 user_id
    const tokenResult = verifyToken(event);
    if (!tokenResult.success) {
        return {
            code: 401,
            message: tokenResult.error || '未登录，请先登录',
            data: null
        };
    }
    const user_id = tokenResult.userId;
    
    const { avatar, nickname, username, bio, location, industry } = event;
    
    // 验证至少要更新一个字段
    if (!avatar && !nickname && !username && !bio && !location && !industry) {
        return {
            code: 400,
            message: '至少需要提供一个要更新的字段',
            data: null
        };
    }
    
    try {
        // 获取数据库引用
        const db = uniCloud.database();
        const usersCollection = db.collection('uni-id-users');
        
        // 先检查用户是否存在
        const userCheck = await usersCollection.doc(user_id).get();
        if (!userCheck.data || userCheck.data.length === 0) {
            console.error('用户不存在:', user_id);
            return {
                code: 404,
                message: '用户不存在',
                data: null
            };
        }
        
        // 构建更新数据
        const updateData = {
            update_time: Date.now()
        };
        
        if (avatar !== undefined) updateData.avatar = avatar;
        if (avatar !== undefined) updateData.avatar_file = avatar; // 兼容不同字段名
        if (nickname !== undefined) updateData.nickname = nickname;
        if (username !== undefined) updateData.username = username;
        if (bio !== undefined) updateData.bio = bio;
        if (location !== undefined) updateData.location = location;
        if (industry !== undefined) updateData.industry = industry;
        
        console.log('准备更新用户信息:', user_id, updateData);
        
        // 更新用户信息
        const result = await usersCollection.doc(user_id).update(updateData);
        
        console.log('更新用户信息结果:', result);
        
        if (result.updated === 0) {
            console.warn('更新失败，updated为0:', result);
            // 即使updated为0，也可能是因为数据没有变化，继续执行
        }
        
        // 获取更新后的用户信息
        const userResult = await usersCollection.doc(user_id).get();
        const userData = userResult.data && userResult.data.length > 0 ? userResult.data[0] : null;
        
        if (!userData) {
            console.error('获取更新后的用户信息失败');
            return {
                code: 500,
                message: '更新后无法获取用户信息',
                data: null
            };
        }
        
        console.log('用户信息更新成功');
        return {
            code: 200,
            message: '更新成功',
            data: {
                user_id: user_id,
                ...updateData,
                userInfo: userData
            }
        };
    } catch (error) {
        console.error('更新用户信息失败:', error);
        console.error('错误堆栈:', error.stack);
        
        let errorMessage = '更新失败';
        if (error && error.message) {
            errorMessage = error.message;
        } else if (typeof error === 'string') {
            errorMessage = error;
        }
        
        // 检查是否是权限错误
        if (errorMessage.includes('permission') || errorMessage.includes('权限')) {
            errorMessage = '没有更新权限，请检查数据库权限配置';
        } else if (errorMessage.includes('not found') || errorMessage.includes('不存在')) {
            errorMessage = '数据库集合不存在，请检查数据库配置';
        }
        
        return {
            code: 500,
            message: errorMessage,
            data: null
        };
    }
};

