// 记录用户主页被浏览云函数
// 调用方式：uniCloud.callFunction({ name: 'recordProfileView', data: { token, viewed_user_id } })

'use strict';

const { verifyToken } = require('./common/authHelper');

/**
 * 统一响应格式
 */
function createResponse(code, message, data = null) {
  return {
    code,
    message,
    data
  };
}

exports.main = async (event, context) => {
  const db = uniCloud.database();
  const usersCollection = db.collection('uni-id-users');

  const res = createResponse;

  try {
    // 验证token并获取当前用户ID（浏览者）
    const authResult = verifyToken(event);
    if (!authResult.success) {
      return res(401, authResult.error);
    }

    const viewerId = authResult.userId;
    const { viewed_user_id } = event;

    if (!viewed_user_id) {
      return res(400, '参数错误：viewed_user_id不能为空');
    }

    // 检查被浏览用户是否存在
    const userCheck = await usersCollection.doc(viewed_user_id).get();
    if (!userCheck.data || userCheck.data.length === 0) {
      return res(404, '被浏览用户不存在');
    }

    // 使用原子操作累加 profile_views 字段
    // 如果字段不存在，初始化为0后再加1
    await usersCollection.doc(viewed_user_id).update({
      profile_views: db.command.inc(1)
    });

    console.log(`用户 ${viewerId} 浏览了用户 ${viewed_user_id} 的主页`);

    return res(200, '记录成功', null);
  } catch (err) {
    console.error('recordProfileView error:', err);
    return res(500, '服务器内部错误', { error: err.message });
  }
};
















