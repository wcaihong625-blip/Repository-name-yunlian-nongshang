// 开店申请云函数
// 调用方式：uniCloud.callFunction({ name: 'openShop', data: { ... } })

'use strict';

exports.main = async (event, context) => {
  const db = uniCloud.database();
  const shopCollection = db.collection('shop_list');
  const usersCollection = db.collection('uni-id-users');

  const res = (code, message, data) => {
    return { code, message, data: data || null };
  };

  try {
    const {
      shopName,
      category,
      region,
      address,
      contactName,
      phone,
      image,
      plan,
      user_id
    } = event;

    // 参数验证
    if (!shopName || !category || !region || !address || !contactName || !phone || !image || !user_id) {
      return res(400, '参数错误：必填字段不能为空');
    }

    // 店铺名称长度验证
    if (shopName.trim().length < 2) {
      return res(400, '店铺名称长度至少需要2个字符');
    }

    // 手机号格式验证
    const phoneReg = /^1[3-9]\d{9}$/;
    if (!phoneReg.test(phone)) {
      return res(400, '手机号格式错误');
    }

    // 验证用户是否存在
    const userRes = await usersCollection.doc(user_id).get();
    if (!userRes.data || userRes.data.length === 0) {
      return res(400, '用户不存在');
    }

    const user = userRes.data[0];

    // 检查该用户是否已经申请过店铺
    const existingShop = await shopCollection.where({
      user_id: user_id
    }).get();

    if (existingShop.data && existingShop.data.length > 0) {
      // 检查是否有已通过或待审核的店铺
      const activeShop = existingShop.data.find(shop => 
        shop.status === '已通过' || shop.status === '待审核'
      );
      if (activeShop) {
        return res(400, '您已经申请过店铺，请勿重复申请');
      }
    }

    // 检查店铺名称是否已被使用
    const shopNameExist = await shopCollection.where({
      shopName: shopName.trim(),
      status: { $in: ['已通过', '待审核'] }
    }).count();

    if (shopNameExist.total > 0) {
      return res(400, '店铺名称已被使用，请更换其他名称');
    }

    // 构建店铺信息对象
    const shopData = {
      shopName: shopName.trim(),
      category: category.trim(),
      region: region.trim(),
      address: address.trim(),
      contactName: contactName.trim(),
      phone: phone.trim(),
      image: image, // 图片URL
      plan: plan || 'vip', // 套餐类型：vip（金牌商家）
      user_id: user_id,
      owner: user.nickname || user.username || '未知用户', // 冗余字段，便于查询
      status: '待审核', // 状态：待审核、已通过、已拒绝
      created_date: new Date(),
      updated_date: new Date(),
      approved_date: null, // 审核通过时间
      rejected_reason: null // 拒绝原因
    };

    // 插入数据库
    const insertRes = await shopCollection.add(shopData);

    if (insertRes.id) {
      return res(200, '开店申请提交成功，请等待审核', {
        id: insertRes.id,
        ...shopData
      });
    } else {
      return res(500, '提交失败，请重试');
    }
  } catch (err) {
    console.error('openShop error:', err);
    return res(500, '服务器内部错误', { error: err.message });
  }
};



