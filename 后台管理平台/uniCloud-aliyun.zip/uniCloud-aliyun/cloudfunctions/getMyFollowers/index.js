// 获取我的粉丝列表云函数
// 调用方式：uniCloud.callFunction({ name: 'getMyFollowers', data: { token, page, pageSize } })

'use strict';

const { verifyToken, createResponse } = require('./common/authHelper');

exports.main = async (event, context) => {
  const db = uniCloud.database();
  const followsCollection = db.collection('user_follows');
  const usersCollection = db.collection('uni-id-users');

  const res = createResponse;

  try {
    // 验证token并获取当前用户ID
    const authResult = verifyToken(event);
    if (!authResult.success) {
      return res(401, authResult.error);
    }

    const userId = authResult.userId;
    const page = event.page || 1;
    const pageSize = event.pageSize || 10;

    // 查询粉丝列表（关注我的用户）
    const followersRes = await followsCollection
      .where({
        following_id: userId
      })
      .orderBy('created_date', 'desc')
      .skip((page - 1) * pageSize)
      .limit(pageSize)
      .get();

    // 获取总数
    const totalRes = await followsCollection
      .where({
        following_id: userId
      })
      .count();

    const total = totalRes.total;
    const followerIds = followersRes.data.map(item => item.follower_id);

    // 批量获取用户信息
    let usersData = [];
    if (followerIds.length > 0) {
      const usersRes = await usersCollection
        .where({
          _id: db.command.in(followerIds)
        })
        .get();

      // 查询我是否关注了这些粉丝（用于判断相互关注）
      const myFollowsRes = await followsCollection
        .where({
          follower_id: userId,
          following_id: db.command.in(followerIds)
        })
        .get();

      const myFollowingSet = new Set(myFollowsRes.data.map(item => item.following_id));

      // 创建用户ID到用户信息的映射
      const userMap = {};
      usersRes.data.forEach(user => {
        userMap[user._id] = {
          id: user._id,
          username: user.username || '',
          nickname: user.nickname || user.username || '用户',
          avatar: user.avatar || '',
          location: user.location || '',
          industry: user.industry || '',
          bio: user.bio || '',
          isRealNameVerified: user.isRealNameVerified || false,
          isEnterpriseVerified: user.isEnterpriseVerified || false,
          companyName: user.companyName || '',
          isFollowing: myFollowingSet.has(user._id) // 判断是否相互关注
        };
      });

      // 按照关注时间排列用户信息
      usersData = followerIds.map(id => userMap[id]).filter(Boolean);

      // 为每个用户添加关注时间
      usersData.forEach((user, index) => {
        const followRecord = followersRes.data[index];
        user.followed_date = followRecord.created_date;
      });
    }

    return res(200, '获取成功', {
      data: usersData,
      total: total,
      page: page,
      pageSize: pageSize,
      hasMore: (page * pageSize) < total
    });
  } catch (err) {
    console.error('getMyFollowers error:', err);
    return res(500, '服务器内部错误', { error: err.message });
  }
};

