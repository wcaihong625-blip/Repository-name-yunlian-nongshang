// 获取采购列表云函数
// 调用方式：uniCloud.callFunction({ name: 'getPurchaseList', data: { page, pageSize, category, search, user_id } })

'use strict';

exports.main = async (event, context) => {
  const db = uniCloud.database();
  const purchaseCollection = db.collection('purchase_list');

  const res = (code, message, data) => {
    return { code, message, data: data || null };
  };

  try {
    const {
      page = 1,
      pageSize = 10,
      category,
      search,
      user_id // 如果提供user_id，则只返回该用户发布的采购
    } = event;

    console.log('getPurchaseList 参数:', { page, pageSize, category, search, user_id });

    // 构建查询条件
    let whereCondition = {};

    // 如果提供了user_id，只查询该用户的采购
    if (user_id) {
      whereCondition.user_id = user_id;
      console.log('查询我的采购列表，user_id:', user_id);
    } else {
      // 公开列表显示已发布的，以及审核中的（审核中的会在返回时转换为已发布）
      whereCondition.status = db.command.in(['已发布', '审核中']);
      console.log('查询公开采购列表，状态过滤: 已发布 或 审核中');
    }

    // 分类筛选
    if (category && category !== '全部') {
      whereCondition.category = category;
    }

    // 搜索关键词（标题、规格）
    if (search && search.trim()) {
      const searchRegex = new RegExp(search.trim(), 'i');
      whereCondition.$or = [
        { title: searchRegex },
        { specifications: searchRegex }
      ];
    }

    // 构建查询
    let query = purchaseCollection.where(whereCondition);

    // 排序：默认按时间降序（最新在前）
    query = query.orderBy('created_date', 'desc');

    // 分页
    const skip = (page - 1) * pageSize;
    query = query.skip(skip).limit(pageSize);

    // 执行查询
    const queryRes = await query.get();
    console.log('查询结果数量:', queryRes.data.length);

    // 获取总数
    const countRes = await purchaseCollection.where(whereCondition).count();
    console.log('总记录数:', countRes.total);

    // 格式化数据
    const formattedData = queryRes.data.map(item => {
      // 计算相对时间
      const timeAgo = getTimeAgo(item.created_date);
      
      // 如果是"审核中"或"审核失败"状态，自动转换为"已发布"
      let status = item.status;
      if (status === '审核中' || status === '审核失败') {
        status = '已发布';
      }
      
      return {
        id: item._id,
        title: item.title,
        category: item.category,
        specifications: item.specifications,
        quantity: item.quantity,
        unit: item.unit,
        price: item.price,
        address: item.address,
        location: item.address, // 兼容前端使用location字段
        remarks: item.remarks || '',
        publisher: item.publisher,
        user_id: item.user_id,
        status: status,
        urgency: item.urgency || 'Normal',
        time: timeAgo,
        created_date: item.created_date,
        isFavorite: false // 前端需要根据本地存储判断
      };
    });

    return res(200, '获取成功', {
      list: formattedData,
      total: countRes.total,
      page: page,
      pageSize: pageSize,
      hasMore: skip + formattedData.length < countRes.total
    });
  } catch (err) {
    console.error('getPurchaseList error:', err);
    return res(500, '服务器内部错误', { error: err.message });
  }
};

// 计算相对时间
function getTimeAgo(timestamp) {
  if (!timestamp) return '';
  
  const now = new Date();
  const time = timestamp instanceof Date ? timestamp : new Date(timestamp);
  const diff = now - time;
  
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);
  
  if (minutes < 1) {
    return '刚刚';
  } else if (minutes < 60) {
    return `${minutes}分钟前`;
  } else if (hours < 24) {
    return `${hours}小时前`;
  } else if (days < 30) {
    return `${days}天前`;
  } else {
    const year = time.getFullYear();
    const month = String(time.getMonth() + 1).padStart(2, '0');
    const day = String(time.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }
}


