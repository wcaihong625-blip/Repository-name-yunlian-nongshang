'use strict';

const { verifyToken } = require('./common/authHelper');

function safeString(value) {
  return value === undefined || value === null ? '' : String(value).trim();
}

exports.main = async (event, context) => {
  const db = uniCloud.database();
  const _ = db.command;
  

  const token = safeString(event.uniIdToken || event.token || '');
  if (!token) {
    return { code: 401, message: '请先登录' };
  }

  let payload;
  try {
    payload = await uniIDIns.checkToken(token);
    if (!payload || (payload.code !== 0 && !tokenResult.userId) || !tokenResult.userId) {
      return { code: 401, message: '请先登录' };
    }
  } catch (e) {
    return { code: 401, message: '登录失效，请重新登录' };
  }

  const uid = tokenResult.userId;
  const customerId = safeString(event.customer_id);
  const newSalesId = safeString(event.new_sales_id);
  const applyReason = safeString(event.apply_reason);
  const mobile = safeString(event.mobile);

  if (!customerId || !newSalesId) {
    return { code: 400, message: '缺少必填参数 customer_id 或 new_sales_id' };
  }

  try {
    // 1. 获取申请人信息
    const applyUserRes = await db.collection('uni-id-users').doc(uid).get();
    const applyUser = applyUserRes.data && applyUserRes.data.length ? applyUserRes.data[0] : {};
    const applyUserName = applyUser.nickname || applyUser.username || '';

    // 2. 查询客户信息
    const customerRes = await db.collection('customer_profile').doc(customerId).get();
    const customerProfile = customerRes.data && customerRes.data.length ? customerRes.data[0] : null;

    if (!customerProfile) {
      return { code: 404, message: '客户不存在' };
    }

    const currentSalesId = safeString(customerProfile.current_sales_id);
    const currentSalesName = safeString(customerProfile.current_sales_name);

    if (currentSalesId === newSalesId) {
      return { code: 400, message: '新归属业务员不能与当前业务员相同' };
    }

    // 3. 查询新业务员姓名
    let newSalesName = '';
    const newSalesRes = await db.collection('sales_staff').doc(newSalesId).get();
    if (newSalesRes.data && newSalesRes.data.length) {
      newSalesName = safeString(newSalesRes.data[0].sales_name);
    } else {
      return { code: 404, message: '指定的新业务员不存在' };
    }

    // 4. 校验是否已有待审批的申请
    const pendingQuery = {
      customer_id: customerId,
      audit_status: 0
    };
    const pendingRes = await db.collection('customer_transfer_apply').where(pendingQuery).limit(1).get();
    if (pendingRes.data && pendingRes.data.length > 0) {
      return { code: 400, message: '该客户已有待审批的转移申请，请勿重复提交' };
    }

    const nowDate = new Date();

    // 5. 创建申请记录
    const applyData = {
      customer_id: customerId,
      mobile: safeString(customerProfile.mobile || mobile),
      old_sales_id: currentSalesId,
      old_sales_name: currentSalesName,
      new_sales_id: newSalesId,
      new_sales_name: newSalesName,
      apply_user_id: uid,
      apply_user_name: applyUserName,
      apply_reason: applyReason,
      audit_status: 0,
      created_at: nowDate,
      updated_at: nowDate
    };

    const addRes = await db.collection('customer_transfer_apply').add(applyData);
    const applyId = addRes.id || addRes.insertedId;

    // 6. 同时更新 customer_profile.transfer_status = 1
    await db.collection('customer_profile').doc(customerId).update({
      transfer_status: 1,
      updated_at: nowDate
    });

    return {
      code: 200,
      message: '发起申请成功',
      data: {
        apply_id: applyId,
        customer_id: customerId,
        old_sales_id: currentSalesId,
        new_sales_id: newSalesId,
        audit_status: 0
      }
    };

  } catch (e) {
    console.error('createCustomerTransferApply error:', e);
    return { code: 500, message: e.message || '服务繁忙，请稍后再试' };
  }
};
