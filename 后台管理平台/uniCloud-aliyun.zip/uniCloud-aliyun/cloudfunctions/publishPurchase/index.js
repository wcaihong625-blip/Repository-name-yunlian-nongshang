// 发布采购信息云函数
// 调用方式：uniCloud.callFunction({ name: 'publishPurchase', data: { ... } })

'use strict';

exports.main = async (event, context) => {
  const db = uniCloud.database();
  const purchaseCollection = db.collection('purchase_list');
  const usersCollection = db.collection('uni-id-users');

  const res = (code, message, data) => {
    return { code, message, data: data || null };
  };

  try {
    const {
      title,
      category,
      specifications,
      quantity,
      unit,
      price,
      address,
      remarks,
      user_id,
      urgency
    } = event;

    // 参数验证
    if (!title || !category || !specifications || !quantity || !unit || !price || !address || !user_id) {
      return res(400, '参数错误：必填字段不能为空');
    }

    // 验证用户是否存在
    const userRes = await usersCollection.doc(user_id).get();
    if (!userRes.data || userRes.data.length === 0) {
      return res(400, '用户不存在');
    }

    const user = userRes.data[0];
    const publisher = user.nickname || user.username || '未知用户';

    // 构建采购信息对象
    const purchaseData = {
      title: title.trim(),
      category: category.trim(),
      specifications: specifications.trim(),
      quantity: quantity.trim(),
      unit: unit.trim(),
      price: price.trim(),
      address: address.trim(),
      remarks: remarks ? remarks.trim() : '',
      user_id: user_id,
      publisher: publisher,
      status: '已发布', // 直接发布，无需审核
      urgency: urgency || 'Normal',
      created_date: new Date(),
      updated_date: new Date()
    };

    // 插入数据库
    const insertRes = await purchaseCollection.add(purchaseData);

    if (insertRes.id) {
      return res(200, '发布成功', {
        id: insertRes.id,
        ...purchaseData
      });
    } else {
      return res(500, '发布失败，请重试');
    }
  } catch (err) {
    console.error('publishPurchase error:', err);
    return res(500, '服务器内部错误', { error: err.message });
  }
};


