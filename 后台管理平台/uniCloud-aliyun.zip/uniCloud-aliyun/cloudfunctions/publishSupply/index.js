// 发布供应信息云函数
// 调用方式：uniCloud.callFunction({ name: 'publishSupply', data: { ... } })

'use strict';

exports.main = async (event, context) => {
  const db = uniCloud.database();
  const supplyCollection = db.collection('supply_list');
  const usersCollection = db.collection('uni-id-users');

  const res = (code, message, data) => {
    return { code, message, data: data || null };
  };

  try {
    const {
      title,
      category,
      specifications,
      quantity,
      unit,
      price,
      location,
      images,
      description,
      user_id
    } = event;

    // 参数验证
    if (!title || !category || !specifications || !quantity || !unit || !price || !location || !description || !user_id) {
      return res(400, '参数错误：必填字段不能为空');
    }

    if (!images || images.length === 0) {
      return res(400, '参数错误：至少需要上传一张产品图片');
    }

    // 验证用户是否存在
    const userRes = await usersCollection.doc(user_id).get();
    if (!userRes.data || userRes.data.length === 0) {
      return res(400, '用户不存在');
    }

    const user = userRes.data[0];
    const publisher = user.nickname || user.username || '未知用户';

    // 构建供应信息对象
    const supplyData = {
      title: title.trim(),
      category: category.trim(),
      specifications: specifications.trim(),
      quantity: quantity.trim(),
      unit: unit.trim(),
      price: price.trim(),
      location: location.trim(),
      images: Array.isArray(images) ? images : [],
      description: description.trim(),
      user_id: user_id,
      publisher: publisher,
      status: '已发布', // 直接发布，无需审核
      created_date: new Date(),
      updated_date: new Date()
    };

    // 插入数据库
    const insertRes = await supplyCollection.add(supplyData);

    if (insertRes.id) {
      return res(200, '发布成功', {
        id: insertRes.id,
        ...supplyData
      });
    } else {
      return res(500, '发布失败，请重试');
    }
  } catch (err) {
    console.error('publishSupply error:', err);
    return res(500, '服务器内部错误', { error: err.message });
  }
};


