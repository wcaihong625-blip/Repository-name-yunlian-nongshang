'use strict';

const { verifyToken } = require('./common/authHelper');

function safeString(value) {
  return value === undefined || value === null ? '' : String(value).trim();
}

function getMonthBoundaries(monthStr) {
  // monthStr: YYYY-MM
  const match = monthStr.match(/^(\d{4})-(\d{2})$/);
  if (!match) return null;
  const year = parseInt(match[1], 10);
  const month = parseInt(match[2], 10);
  if (month < 1 || month > 12) return null;
  
  // 以当地时区创建起止界限
  const startDate = new Date(`${year}-${String(month).padStart(2, '0')}-01T00:00:00+08:00`);
  let nextMonth = month + 1;
  let nextYear = year;
  if (nextMonth > 12) {
    nextMonth = 1;
    nextYear++;
  }
  const endDate = new Date(new Date(`${nextYear}-${String(nextMonth).padStart(2, '0')}-01T00:00:00+08:00`).getTime() - 1);
  return { start: startDate, end: endDate };
}

exports.main = async (event, context) => {
  const db = uniCloud.database();
  const _ = db.command;

  // 统一认证校验
  const tokenResult = verifyToken(event);
  if (!tokenResult.success) {
    return { code: 401, message: tokenResult.error || '登录失效，请重新登录' };
  }

  const settleMonth = safeString(event.settle_month);
  if (!settleMonth) return { code: 400, message: '缺少参数 settle_month' };

  const bounds = getMonthBoundaries(settleMonth);
  if (!bounds) return { code: 400, message: 'settle_month 格式错误，应为 YYYY-MM' };

  try {
    // 1. 查询所有未结算且满足条件的订单
    const orderQuery = _.and([
      { order_status: 1 },
      { commission_amount: _.gt(0) },
      { commission_status: 0 },
      // 修复过滤条件同名覆盖问题：改为使用 _.and 包裹多个不等条件
      { sales_id: _.and(_.neq(''), _.neq(null)) },
      // 兼容 pay_time 为 Date 对象或毫秒数
      _.or([
        { pay_time: _.gte(bounds.start).and(_.lte(bounds.end)) },
        { pay_time: _.gte(bounds.start.getTime()).and(_.lte(bounds.end.getTime())) }
      ])
    ]);

    const MAX_LIMIT = 2000;
    const ordersRes = await db.collection('member_order').where(orderQuery).limit(MAX_LIMIT).get();
    const orders = ordersRes.data || [];

    if (orders.length === 0) {
      return { code: 200, message: '该月份无未结算订单', data: { settle_month: settleMonth, created_count: 0, settle_ids: [] } };
    }

    // 2. 按业务员分组统计
    const salesMap = {};
    for (let order of orders) {
      const sId = safeString(order.sales_id);
      if (!sId) continue;
      if (!salesMap[sId]) {
        salesMap[sId] = {
          sales_id: sId,
          sales_name: safeString(order.sales_name),
          order_count: 0,
          first_open_count: 0,
          renewal_count: 0,
          first_open_amount: 0,
          renewal_amount: 0,
          first_open_commission: 0,
          renewal_commission: 0,
          commission_total: 0,
          order_ids: []
        };
      }

      const mapItem = salesMap[sId];
      const isFirst = (order.order_type === 1 || order.commission_type === 'first_open');
      const isRenewal = (order.order_type === 2 || order.commission_type === 'renewal');
      
      mapItem.order_count += 1;
      mapItem.order_ids.push(order._id);
      const payAmount = Number(order.pay_amount) || 0;
      const commAmount = Number(order.commission_amount) || 0;
      
      mapItem.commission_total += commAmount;
      
      if (isFirst) {
        mapItem.first_open_count += 1;
        mapItem.first_open_amount += payAmount;
        mapItem.first_open_commission += commAmount;
      } else if (isRenewal) {
        mapItem.renewal_count += 1;
        mapItem.renewal_amount += payAmount;
        mapItem.renewal_commission += commAmount;
      } else {
        // 兜底全进续费
        mapItem.renewal_count += 1;
        mapItem.renewal_amount += payAmount;
        mapItem.renewal_commission += commAmount;
      }
    }

    // 3. 防重判断：查询当前结算月份已有的业务员
    const targetSalesIds = Object.keys(salesMap);
    const existingSettleRes = await db.collection('sales_commission_settle').where({
      settle_month: settleMonth,
      sales_id: _.in(targetSalesIds)
    }).get();
    const existingSales = (existingSettleRes.data || []).map(item => safeString(item.sales_id));

    // 4. 构建记录并入库
    const nowDate = new Date();
    const creates = [];
    for (let sId of targetSalesIds) {
      if (existingSales.includes(sId)) {
        continue; // 该业务员在此月已生成过未删除的结算单
      }
      const data = salesMap[sId];
      creates.push({
        sales_id: data.sales_id,
        sales_name: data.sales_name,
        settle_month: settleMonth,
        order_count: data.order_count,
        first_open_count: data.first_open_count,
        renewal_count: data.renewal_count,
        first_open_amount: Number(data.first_open_amount.toFixed(2)),
        renewal_amount: Number(data.renewal_amount.toFixed(2)),
        first_open_commission: Number(data.first_open_commission.toFixed(2)),
        renewal_commission: Number(data.renewal_commission.toFixed(2)),
        commission_total: Number(data.commission_total.toFixed(2)),
        commission_paid: 0,
        commission_unpaid: Number(data.commission_total.toFixed(2)),
        settle_status: 0, // 0=待结算
        order_ids: data.order_ids,
        remark: '',
        created_at: nowDate,
        updated_at: nowDate
      });
    }

    if (creates.length === 0) {
       return { code: 200, message: '该月份有待结算订单，但匹配的业务员均已生成过账单，无新生成项目', data: { settle_month: settleMonth, created_count: 0, settle_ids: [] } };
    }

    const addRes = await db.collection('sales_commission_settle').add(creates);
    const settleIds = addRes.insertedIds || [addRes.id || addRes.insertedId];

    return {
      code: 200,
      message: '生成结算单成功',
      data: {
        settle_month: settleMonth,
        created_count: creates.length,
        settle_ids: settleIds
      }
    };
  } catch (e) {
    console.error('generateCommissionSettle error:', e);
    return { code: 500, message: e.message || '服务繁忙，请稍后再试' };
  }
};
