// 更新供应信息云函数
// 调用方式：uniCloud.callFunction({ name: 'updateSupply', data: { token, id, ... } })

'use strict';

const { verifyToken } = require('./common/authHelper');

exports.main = async (event, context) => {
  const db = uniCloud.database();
  const supplyCollection = db.collection('supply_list');

  const res = (code, message, data) => {
    return { code, message, data: data || null };
  };

  try {
    // 验证 token 并获取 user_id
    const tokenResult = verifyToken(event);
    if (!tokenResult.success) {
      return res(401, tokenResult.error || '未登录，请先登录');
    }
    const user_id = tokenResult.userId;

    const {
      id,
      title,
      category,
      specifications,
      quantity,
      unit,
      price,
      location,
      images,
      description
    } = event;

    // 参数验证
    if (!id) {
      return res(400, '参数错误：供应ID不能为空');
    }

    if (!title || !category || !specifications || !quantity || !unit || !price || !location || !description) {
      return res(400, '参数错误：必填字段不能为空');
    }

    if (!images || images.length === 0) {
      return res(400, '参数错误：至少需要上传一张产品图片');
    }

    // 查询该供应信息，验证归属
    const supplyRes = await supplyCollection.doc(id).get();
    if (!supplyRes.data || supplyRes.data.length === 0) {
      return res(404, '供应信息不存在');
    }

    const supply = supplyRes.data[0];
    if (supply.user_id !== user_id) {
      return res(403, '无权修改此供应信息');
    }

    // 构建更新数据
    const updateData = {
      title: title.trim(),
      category: category.trim(),
      specifications: specifications.trim(),
      quantity: String(quantity).trim(),
      unit: unit.trim(),
      price: String(price).trim(),
      location: location.trim(),
      images: Array.isArray(images) ? images : [],
      description: description.trim(),
      created_date: new Date(),
      updated_date: new Date()
    };

    // 更新数据库
    await supplyCollection.doc(id).update(updateData);

    return res(200, '修改成功', {
      id: id,
      ...updateData
    });

  } catch (err) {
    console.error('updateSupply error:', err);
    return res(500, '服务器内部错误', { error: err.message });
  }
};
