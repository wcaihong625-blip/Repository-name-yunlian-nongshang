'use strict';

const db = uniCloud.database();

exports.main = async (event, context) => {
  // 兼容：既支持 callFunction 直传，也支持 HTTP 传 event.body
  let body = {};
  try {
    body = event && event.body ? JSON.parse(event.body) : (event || {});
  } catch (e) {
    body = event || {};
  }

  const {
    type,                 // 'origin' | 'wholesale' | 'analysis'
    page = 1,
    pageSize = 20,
    name,                 // 可选：品种名，如 '土豆'
    search,               // 兼容前端：可能传 search
    location,             // 可选：地点关键字
    date                  // 可选：YYYY-MM-DD
  } = body;

  if (!type || !['origin', 'wholesale', 'analysis'].includes(type)) {
    return { success: false, message: 'invalid type' };
  }

  const collectionName =
    type === 'origin'
      ? 'ymt_origin_price'
      : type === 'wholesale'
        ? 'ymt_wholesale_price'
        : 'ymt_analysis_text';

  const col = db.collection(collectionName);

  // 构建查询条件
  const where = {};

  // 关键修复：origin/wholesale 必须按 data_type 过滤，防止历史脏数据混入
  if (type === 'origin' || type === 'wholesale') {
    where.data_type = type;
  }

  const kw = name || search;
  if (kw) {
    // analysis 文案：模糊匹配；价格表：先精确匹配（你也可以改成模糊）
    where.name = type === 'analysis' ? new RegExp(kw, 'i') : kw;
  }

  if (date) where.date = date;
  if (location) where.location = new RegExp(location);

  const _page = Math.max(1, Number(page));
  const _pageSize = Math.min(1000, Math.max(1, Number(pageSize)));
  const skip = (_page - 1) * _pageSize;

  // 多取一些再过滤（price<=0），避免本页被过滤空
  const fetchSize = Math.min(5000, _pageSize * 5);

  const listRes = await col
    .where(where)
    .orderBy('date', 'desc')
    .orderBy('_id', 'desc')
    .skip(skip)
    .limit(fetchSize)
    .get();

  const rawList = listRes.data || [];

  // origin/wholesale：过滤无效价格；analysis：不参与价格过滤
  const filtered = type === 'analysis'
    ? rawList
    : rawList
        // 双保险：再次保证 data_type 不串
        .filter(x => x && x.data_type === type)
        .filter(x => {
          const p = Number(x && x.price);
          return Number.isFinite(p) && p > 0;
        });

  const list = filtered.slice(0, _pageSize);

  const totalRes = await col.where(where).count();
  const total = totalRes.total || 0;

  return {
    success: true,
    type,
    page: _page,
    pageSize: _pageSize,
    total,
    valid_count_in_page: list.length,
    list
  };
};
