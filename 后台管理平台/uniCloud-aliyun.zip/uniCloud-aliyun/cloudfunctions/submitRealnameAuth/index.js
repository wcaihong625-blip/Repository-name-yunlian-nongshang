// 提交实名认证信息云函数
// 调用方式：uniCloud.callFunction({ name: 'submitRealnameAuth', data: { ... } })

'use strict';

exports.main = async (event, context) => {
  const db = uniCloud.database();
  const authCollection = db.collection('realname_auth');
  const usersCollection = db.collection('uni-id-users');

  const res = (code, message, data) => {
    return { code, message, data: data || null };
  };

  try {
    const {
      user_id,
      realName,
      idCard,
      idCardFront,
      idCardBack
    } = event;

    // 参数验证
    if (!user_id || !realName || !idCard || !idCardFront || !idCardBack) {
      return res(400, '参数错误：必填字段不能为空');
    }

    // 验证姓名长度
    if (realName.trim().length < 2 || realName.trim().length > 20) {
      return res(400, '真实姓名长度应在2-20个字符之间');
    }

    // 验证身份证号格式
    const idCardRegex = /^[1-9]\d{5}(18|19|20)\d{2}(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])\d{3}[\dXx]$/;
    if (!idCardRegex.test(idCard)) {
      return res(400, '身份证号码格式不正确');
    }

    // 验证用户是否存在
    const userRes = await usersCollection.doc(user_id).get();
    if (!userRes.data || userRes.data.length === 0) {
      return res(400, '用户不存在');
    }

    // 检查该用户是否已有认证记录
    const existingAuth = await authCollection.where({
      user_id: user_id
    }).get();

    if (existingAuth.data && existingAuth.data.length > 0) {
      const authRecord = existingAuth.data[0];
      // 如果已有待审核或已通过的记录，不允许重复提交
      if (authRecord.status === 'pending' || authRecord.status === 'verified') {
        return res(400, '您已有认证记录，无法重复提交');
      }
      // 如果是被驳回的记录，更新现有记录
      if (authRecord.status === 'rejected') {
        const updateData = {
          realName: realName.trim(),
          idCard: idCard.toUpperCase(),
          idCardFront: idCardFront,
          idCardBack: idCardBack,
          status: 'pending',
          rejectReason: '',
          updated_date: new Date()
        };

        const updateRes = await authCollection.doc(authRecord._id).update(updateData);
        
        if (updateRes.updated > 0) {
          return res(200, '提交成功，等待审核', {
            id: authRecord._id,
            status: 'pending',
            ...updateData
          });
        } else {
          return res(500, '提交失败，请重试');
        }
      }
    }

    // 检查该身份证号是否已被其他用户使用
    const idCardCheck = await authCollection.where({
      idCard: idCard.toUpperCase(),
      status: 'verified'
    }).get();

    if (idCardCheck.data && idCardCheck.data.length > 0) {
      const existingRecord = idCardCheck.data[0];
      if (existingRecord.user_id !== user_id) {
        return res(400, '该身份证号已被其他用户认证使用');
      }
    }

    // 构建认证信息对象
    const authData = {
      user_id: user_id,
      realName: realName.trim(),
      idCard: idCard.toUpperCase(),
      idCardFront: idCardFront,
      idCardBack: idCardBack,
      status: 'pending',
      created_date: new Date(),
      updated_date: new Date()
    };

    // 如果有旧记录，更新；否则新增
    if (existingAuth.data && existingAuth.data.length > 0) {
      const updateRes = await authCollection.doc(existingAuth.data[0]._id).update(authData);
      
      if (updateRes.updated > 0) {
        return res(200, '提交成功，等待审核', {
          id: existingAuth.data[0]._id,
          ...authData
        });
      } else {
        return res(500, '提交失败，请重试');
      }
    } else {
      // 插入数据库
      const insertRes = await authCollection.add(authData);

      if (insertRes.id) {
        return res(200, '提交成功，等待审核', {
          id: insertRes.id,
          ...authData
        });
      } else {
        return res(500, '提交失败，请重试');
      }
    }
  } catch (err) {
    console.error('submitRealnameAuth error:', err);
    return res(500, '服务器内部错误', { error: err.message });
  }
};

