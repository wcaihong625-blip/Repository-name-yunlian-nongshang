// 取消关注用户云函数
// 调用方式：uniCloud.callFunction({ name: 'unfollowUser', data: { token, following_id } })

'use strict';

const { verifyToken, createResponse } = require('./common/authHelper');

exports.main = async (event, context) => {
  const db = uniCloud.database();
  const followsCollection = db.collection('user_follows');

  const res = createResponse;

  try {
    // 验证token并获取当前用户ID
    const authResult = verifyToken(event);
    if (!authResult.success) {
      return res(401, authResult.error);
    }

    const followerId = authResult.userId;
    const { following_id } = event;

    if (!following_id) {
      return res(400, '参数错误：following_id不能为空');
    }

    // 查找关注关系
    const followRelation = await followsCollection
      .where({
        follower_id: followerId,
        following_id: following_id
      })
      .get();

    if (!followRelation.data || followRelation.data.length === 0) {
      return res(400, '您还没有关注该用户');
    }

    // 删除关注关系
    await followsCollection
      .where({
        follower_id: followerId,
        following_id: following_id
      })
      .remove();

    console.log(`用户 ${followerId} 取消关注了用户 ${following_id}`);

    return res(200, '取消关注成功');
  } catch (err) {
    console.error('unfollowUser error:', err);
    return res(500, '服务器内部错误', { error: err.message });
  }
};

