'use strict';

// 获取系统配置云函数
// 调用方式：uniCloud.callFunction({ name: 'getSystemSettings', data: {} })
// 返回系统配置信息，包括客服电话等

exports.main = async (event, context) => {
  const db = uniCloud.database();
  const collection = db.collection('platform_settings');

  const res = (code, message, data) => {
    return { code, message, data: data || null };
  };

  try {
    console.log('getSystemSettings 开始获取系统配置');

    // 查询系统配置，使用 _id 为 'default' 的记录
    const queryRes = await collection
      .doc('default')
      .get();

    if (!queryRes.data || queryRes.data.length === 0) {
      // 如果不存在，返回默认配置
      console.log('getSystemSettings 配置不存在，返回默认值');
      const defaultSettings = {
        customer_service_phone: '400-123-8888',
        open_shop_price_original: 0,
        open_shop_price_discount: 0,
        realname_stage: 'open_shop'
      };
      return res(200, '获取成功（使用默认配置）', defaultSettings);
    }

    const doc = queryRes.data[0];

    // 返回配置信息（只返回前端需要的字段）
    const settings = {
      customer_service_phone: doc.customer_service_phone || '400-123-8888',
      open_shop_price_original: doc.open_shop_price_original || 0,
      open_shop_price_discount: doc.open_shop_price_discount || 0,
      realname_stage: doc.realname_stage || 'open_shop'
    };

    console.log('getSystemSettings 查询成功:', settings);

    return res(200, '获取成功', settings);
  } catch (err) {
    console.error('getSystemSettings error:', err);
    return res(500, '服务器内部错误', { error: err.message });
  }
};

