'use strict';

// 获取协议内容云函数
// 调用方式：uniCloud.callFunction({ name: 'getAgreement', data: { type: 'user_agreement' } })

exports.main = async (event, context) => {
  const db = uniCloud.database();
  const collection = db.collection('agreements');

  const res = (code, message, data) => {
    return { code, message, data: data || null };
  };

  try {
    const { type } = event;

    if (!type) {
      return res(400, '参数错误：type 不能为空');
    }

    console.log('getAgreement 参数:', { type });

    // 查询指定类型且生效的协议
    const queryRes = await collection
      .where({
        type,
        status: true
      })
      .limit(1)
      .get();

    if (!queryRes.data || queryRes.data.length === 0) {
      return res(404, '协议内容不存在，请在管理后台添加对应类型的协议');
    }

    const doc = queryRes.data[0];

    const data = {
      id: doc._id,
      type: doc.type,
      title: doc.title,
      content: doc.content,
      updated_at: doc.updated_at || doc.update_date || doc.created_at || null
    };

    console.log('getAgreement 查询成功:', data.id, data.type);

    return res(200, '获取成功', data);
  } catch (err) {
    console.error('getAgreement error:', err);
    return res(500, '服务器内部错误', { error: err.message });
  }
};


