// 删除供应/采购信息云函数
// 调用方式：uniCloud.callFunction({ name: 'deleteItem', data: { id, type, user_id } })
// type: 'supply' 或 'purchase'

'use strict';

exports.main = async (event, context) => {
  const db = uniCloud.database();
  
  const res = (code, message, data) => {
    return { code, message, data: data || null };
  };

  try {
    const { id, type, user_id } = event;

    // 参数验证
    if (!id || !type || !user_id) {
      return res(400, '参数错误：id、type、user_id 为必填项');
    }

    if (type !== 'supply' && type !== 'purchase') {
      return res(400, '参数错误：type 必须是 supply 或 purchase');
    }

    // 选择对应的集合
    const collection = type === 'supply' 
      ? db.collection('supply_list')
      : db.collection('purchase_list');

    // 先查询记录，验证所有权
    const itemRes = await collection.doc(id).get();
    
    if (!itemRes.data || itemRes.data.length === 0) {
      return res(404, '记录不存在');
    }

    const item = itemRes.data[0];

    // 验证是否为该用户发布的
    if (item.user_id !== user_id) {
      return res(403, '无权删除此记录');
    }

    // 删除记录
    const deleteRes = await collection.doc(id).remove();

    if (deleteRes.deleted > 0) {
      return res(200, '删除成功');
    } else {
      return res(500, '删除失败，请重试');
    }
  } catch (err) {
    console.error('deleteItem error:', err);
    return res(500, '服务器内部错误', { error: err.message });
  }
};




