// 用户注册云函数
// 调用方式：uniCloud.callFunction({ name: 'user-register', data: { username?, password, mobile?, nickname? } })
// 注意：如果只提供 mobile，会自动使用 mobile 作为 username

/**
 * ----------------------------------------------------
 * 【废弃停用声明】（后台统一登录整理）
 * 本自定义云函数为历史遗留方案。
 * 当前后台管理平台（admin）已全面统一接入官方 `uni-id-co` + `uni-id-pages`。
 * 该文件不再作为主注册链路的一部分，请勿继续使用或扩展，仅作代码存档隔离。
 * ----------------------------------------------------
 */
'use strict';

const bcrypt = require('bcryptjs');

// 生产环境请从环境变量或安全配置中读取
const SALT_ROUNDS = 10;

exports.main = async (event, context) => {
  const db = uniCloud.database();
  const usersCollection = db.collection('uni-id-users');

  let { username, password, mobile, nickname } = event;

  // 统一返回方法
  const res = (code, message, data) => {
    return { code, message, data: data || null };
  };

  try {
    // 参数校验：至少需要 password 和 (username 或 mobile)
    if (!password) {
      return res(400, '参数错误：password 为必填项');
    }

    // 如果只提供了 mobile，使用 mobile 作为 username
    if (!username && mobile) {
      username = mobile;
    }

    if (!username) {
      return res(400, '参数错误：username 或 mobile 至少需要提供一个');
    }

    // 密码强度校验
    if (typeof password !== 'string' || password.length < 6) {
      return res(400, '密码格式错误：长度需不小于6位');
    }

    // 手机号校验（如提供）：中国大陆 11 位，以 1 开头
    if (mobile) {
      const mobileReg = /^1[3-9]\d{9}$/;
      if (!mobileReg.test(mobile)) {
        return res(400, '手机号格式错误');
      }
    }

    // 用户名格式校验：如果 username 是手机号格式，则允许；否则需要4-20位字母数字下划线
    if (mobile && username === mobile) {
      // 使用手机号作为用户名，格式已通过手机号校验
    } else {
      const usernameReg = /^[a-zA-Z0-9_]{4,20}$/;
      if (!usernameReg.test(username)) {
        return res(400, '用户名格式错误：需为4-20位字母、数字或下划线');
      }
    }

    // 查重：用户名
    const usernameExist = await usersCollection.where({ username }).count();
    if (usernameExist.total > 0) {
      return res(400, '用户名已存在');
    }

    // 查重：手机号（如果提供）
    if (mobile) {
      const mobileExist = await usersCollection.where({ mobile }).count();
      if (mobileExist.total > 0) {
        return res(400, '手机号已注册');
      }
    }

    // 密码加密
    const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);

    const now = new Date();

    // 写入数据库
    const addRes = await usersCollection.add({
      username,
      mobile: mobile || '',
      password: passwordHash,
      wx_openid: '',
      nickname: nickname || '',
      avatar: '',
      status: 0, // 0-正常
      created_date: now,
      last_login_date: null
    });

    const userId = addRes.id || (addRes.insertedId && addRes.insertedId.toString());

    return res(200, '注册成功', {
      _id: userId,
      username,
      mobile: mobile || '',
      nickname: nickname || '',
      avatar: '',
      status: 0,
      created_date: now
    });
  } catch (err) {
    console.error('user-register error:', err);
    return res(500, '服务器内部错误', { error: err.message });
  }
};

