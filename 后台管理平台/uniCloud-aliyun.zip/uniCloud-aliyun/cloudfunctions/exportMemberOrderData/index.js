'use strict';

const { verifyToken } = require('./common/authHelper');

function safeString(value) {
  return value === undefined || value === null ? '' : String(value).trim();
}

exports.main = async (event, context) => {
  const db = uniCloud.database();
  const _ = db.command;
  

  const token = safeString(event.uniIdToken || event.token || '');
  if (!token) return { code: 401, message: '请先登录' };

  const tokenResult = verifyToken(event);
    if (!tokenResult.success) {
      return { code: 401, message: tokenResult.error || '登录失效，请重新登录' };
    }

  const queryList = [];

  if (event.mobile) queryList.push({ mobile: new RegExp(String(event.mobile).trim(), 'i') });
  if (event.sales_id) queryList.push({ sales_id: String(event.sales_id).trim() });
  if (event.sales_name) queryList.push({ sales_name: new RegExp(String(event.sales_name).trim(), 'i') });
  
  if (event.order_type !== undefined && event.order_type !== null && event.order_type !== '') {
    queryList.push({ order_type: Number(event.order_type) });
  }
  if (event.order_status !== undefined && event.order_status !== null && event.order_status !== '') {
    queryList.push({ order_status: Number(event.order_status) });
  }
  if (event.commission_status !== undefined && event.commission_status !== null && event.commission_status !== '') {
    queryList.push({ commission_status: Number(event.commission_status) });
  }
  if (event.date_start && event.date_end) {
    const dStart = new Date(event.date_start);
    const dEnd = new Date(event.date_end);
    queryList.push(
      _.or([
        { pay_time: _.gte(dStart).and(_.lte(dEnd)) },
        { pay_time: _.gte(event.date_start).and(_.lte(event.date_end)) }
      ])
    );
  }

  let finalQuery = {};
  if (queryList.length > 0) {
    finalQuery = _.and(queryList);
  }

  try {
    const MAX_LIMIT = 1000;
    let allData = [];
    let skip = 0;
    while(true) {
       const res = await db.collection('member_order').where(finalQuery).skip(skip).limit(MAX_LIMIT).orderBy('created_at', 'desc').get();
       if (!res.data || res.data.length === 0) break;
       allData = allData.concat(res.data);
       if (res.data.length < MAX_LIMIT) break;
       skip += MAX_LIMIT;
    }

    const list = allData.map(item => {
      function formatDate(ts) {
        if (!ts) return '-';
        const d = new Date(ts);
        return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')} ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}:${String(d.getSeconds()).padStart(2,'0')}`;
      }

      let order_type_text = item.order_type === 1 ? '首次开通' : (item.order_type === 2 ? '续费' : '未知');
      
      let order_status_text = '未知';
      if (item.order_status === 0) order_status_text = '待支付';
      else if (item.order_status === 1) order_status_text = '支付成功';
      else if (item.order_status === 2) order_status_text = '已取消';

      let commission_status_text = item.commission_status === 1 ? '已结算' : '未结算';
      
      let commission_type_text = item.commission_type;
      if (item.commission_type === 'first_open') commission_type_text = '首开提成';
      else if (item.commission_type === 'renewal') commission_type_text = '续费提成';

      let currentRate = Number(item.commission_rate) || 0;
      let displayRate = Number((currentRate * 100).toFixed(2));

      return {
        order_no: item.order_no || '',
        mobile: item.mobile || '',
        order_type: item.order_type,
        order_type_text: order_type_text,
        order_status: item.order_status,
        order_status_text: order_status_text,
        pay_amount: item.pay_amount || 0,
        original_amount: item.original_amount || 0,
        member_days: item.member_days || 0,
        pay_time: formatDate(item.pay_time),
        first_sales_name: item.first_sales_name || '',
        sales_name: item.sales_name || '',
        channel_name: item.channel_name || '',
        commission_type: item.commission_type || '',
        commission_type_text: commission_type_text || '',
        commission_rate: displayRate,
        commission_amount: item.commission_amount || 0,
        commission_status: item.commission_status,
        commission_status_text: commission_status_text,
        commission_settle_time: formatDate(item.commission_settle_time),
        created_at: formatDate(item.created_at)
      };
    });

    const headers = [
      'order_no', 'mobile', 'order_type_text', 'order_status_text', 'pay_amount', 'original_amount',
      'member_days', 'pay_time', 'first_sales_name', 'sales_name', 'channel_name', 
      'commission_type_text', 'commission_rate', 'commission_amount', 
      'commission_status_text', 'commission_settle_time', 'created_at'
    ];

    const headers_zh = [
      '订单号', '用户手机号', '订单类型', '支付状态', '支付金额', '原价金额', 
      '购买天数', '支付时间', '首次归属业务员', '现提成业务员', '来源渠道', 
      '提成类型', '提成比例(%)', '提成金额', '结算状态', '结算审批时间', '创建时间'
    ];

    return {
      code: 200,
      message: '导出成功',
      data: {
        headers,
        headers_zh,
        list
      }
    };
  } catch (e) {
    console.error('exportMemberOrderData error:', e);
    return { code: 500, message: '导出失败' };
  }
};
