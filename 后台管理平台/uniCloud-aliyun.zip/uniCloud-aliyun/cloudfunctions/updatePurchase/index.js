// 更新采购信息云函数
// 调用方式：uniCloud.callFunction({ name: 'updatePurchase', data: { token, id, ... } })

'use strict';

const { verifyToken } = require('./common/authHelper');

exports.main = async (event, context) => {
  const db = uniCloud.database();
  const purchaseCollection = db.collection('purchase_list');

  const res = (code, message, data) => {
    return { code, message, data: data || null };
  };

  try {
    // 验证 token 并获取 user_id
    const tokenResult = verifyToken(event);
    if (!tokenResult.success) {
      return res(401, tokenResult.error || '未登录，请先登录');
    }
    const user_id = tokenResult.userId;

    const {
      id,
      title,
      category,
      specifications,
      quantity,
      unit,
      price,
      address,
      remarks
    } = event;

    // 参数验证
    if (!id) {
      return res(400, '参数错误：采购ID不能为空');
    }

    if (!title || !category || !specifications || !quantity || !unit || !price || !address) {
      return res(400, '参数错误：必填字段不能为空');
    }

    // 查询该采购信息，验证归属
    const purchaseRes = await purchaseCollection.doc(id).get();
    if (!purchaseRes.data || purchaseRes.data.length === 0) {
      return res(404, '采购信息不存在');
    }

    const purchase = purchaseRes.data[0];
    if (purchase.user_id !== user_id) {
      return res(403, '无权修改此采购信息');
    }

    // 构建更新数据
    const updateData = {
      title: title.trim(),
      category: category.trim(),
      specifications: specifications.trim(),
      quantity: String(quantity).trim(),
      unit: unit.trim(),
      price: String(price).trim(),
      address: address.trim(),
      remarks: remarks ? String(remarks).trim() : '',
      created_date: new Date(),
      updated_date: new Date()
    };

    // 更新数据库
    await purchaseCollection.doc(id).update(updateData);

    return res(200, '修改成功', {
      id: id,
      ...updateData
    });

  } catch (err) {
    console.error('updatePurchase error:', err);
    return res(500, '服务器内部错误', { error: err.message });
  }
};
