'use strict';

// 更新系统配置云函数
// 调用方式：uniCloud.callFunction({ name: 'updateSystemSettings', data: { token, settings: { customer_service_phone: 'xxx', ... } } })
// 注意：此接口需要管理员权限，供后台管理面板使用

const authHelper = require('./common/authHelper');

exports.main = async (event, context) => {
  const db = uniCloud.database();
  const collection = db.collection('platform_settings');

  const res = (code, message, data) => {
    return { code, message, data: data || null };
  };

  try {
    // 验证 token 并获取用户ID
    const tokenResult = authHelper.verifyToken(event);
    if (!tokenResult.success) {
      return res(401, tokenResult.error || '未登录或登录已过期');
    }

    // 验证是否为管理员
    const usersCollection = db.collection('uni-id-users');
    const userRes = await usersCollection.doc(tokenResult.userId).get();
    if (!userRes.data || !userRes.data.length || !userRes.data[0]) {
      return res(403, '用户不存在');
    }

    const user = userRes.data[0];
    // 检查用户角色是否包含 admin
    const userRoles = user.role || [];
    const isAdmin = Array.isArray(userRoles) 
      ? userRoles.includes('admin')
      : userRoles === 'admin' || (typeof userRoles === 'string' && userRoles.includes('admin'));

    if (!isAdmin) {
      return res(403, '无权访问，需要管理员权限');
    }

    const { settings } = event;

    if (!settings || typeof settings !== 'object') {
      return res(400, '参数错误：settings 必须是一个对象');
    }

    console.log('updateSystemSettings 开始更新系统配置:', settings);

    // 准备更新的字段
    const updateData = {
      update_time: Date.now()
    };

    // 允许更新的字段列表（白名单，防止更新不允许的字段）
    const allowedFields = [
      'customer_service_phone',
      'open_shop_price_original',
      'open_shop_price_discount',
      'realname_stage'
    ];

    // 只更新允许的字段
    allowedFields.forEach(field => {
      if (settings[field] !== undefined) {
        updateData[field] = settings[field];
      }
    });

    // 如果没有任何有效字段，返回错误
    if (Object.keys(updateData).length === 1) { // 只有 update_time
      return res(400, '参数错误：至少需要提供一个有效的配置项');
    }

    // 验证客服电话格式（如果提供了）
    if (updateData.customer_service_phone !== undefined) {
      if (typeof updateData.customer_service_phone !== 'string' || !updateData.customer_service_phone.trim()) {
        return res(400, '参数错误：客服电话必须是非空字符串');
      }
      // 验证电话号码格式（支持多种格式：400-123-8888, 4001238888, +86-400-123-8888 等）
      const phonePattern = /^[\d\-\+\(\)\s]+$/;
      if (!phonePattern.test(updateData.customer_service_phone.trim())) {
        return res(400, '参数错误：客服电话格式不正确');
      }
      updateData.customer_service_phone = updateData.customer_service_phone.trim();
    }

    // 验证价格字段（如果提供了）
    if (updateData.open_shop_price_original !== undefined) {
      if (typeof updateData.open_shop_price_original !== 'number' || updateData.open_shop_price_original < 0) {
        return res(400, '参数错误：开店原价必须是非负数');
      }
    }

    if (updateData.open_shop_price_discount !== undefined) {
      if (typeof updateData.open_shop_price_discount !== 'number' || updateData.open_shop_price_discount < 0) {
        return res(400, '参数错误：开店折后价必须是非负数');
      }
    }

    // 验证实名认证环节（如果提供了）
    if (updateData.realname_stage !== undefined) {
      const validStages = ['none', 'register', 'open_shop', 'publish_goods', 'place_order'];
      if (!validStages.includes(updateData.realname_stage)) {
        return res(400, `参数错误：realname_stage 必须是以下值之一: ${validStages.join(', ')}`);
      }
    }

    // 查询是否存在配置记录
    const existingRes = await collection.doc('default').get();

    let result;
    if (!existingRes.data || existingRes.data.length === 0) {
      // 如果不存在，创建新记录
      console.log('updateSystemSettings 配置不存在，创建新配置');
      const newData = {
        _id: 'default',
        ...updateData,
        create_time: Date.now()
      };
      result = await collection.add(newData);
      console.log('updateSystemSettings 创建成功:', result.id);
    } else {
      // 如果存在，更新记录
      console.log('updateSystemSettings 更新现有配置');
      result = await collection.doc('default').update(updateData);
      console.log('updateSystemSettings 更新成功，影响记录数:', result.updated);
    }

    // 返回更新后的配置
    const updatedRes = await collection.doc('default').get();
    const updatedDoc = updatedRes.data[0];

    const updatedSettings = {
      customer_service_phone: updatedDoc.customer_service_phone || '400-123-8888',
      open_shop_price_original: updatedDoc.open_shop_price_original || 0,
      open_shop_price_discount: updatedDoc.open_shop_price_discount || 0,
      realname_stage: updatedDoc.realname_stage || 'open_shop',
      update_time: updatedDoc.update_time
    };

    return res(200, '更新成功', updatedSettings);
  } catch (err) {
    console.error('updateSystemSettings error:', err);
    return res(500, '服务器内部错误', { error: err.message });
  }
};

