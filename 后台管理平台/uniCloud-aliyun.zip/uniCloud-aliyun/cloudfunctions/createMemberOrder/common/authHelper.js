// 统一身份验证工具模块
// 通过 uni-config-center 官方标准方式读取 JWT 配置
// 配置文件路径: cloudfunctions/common/uni-config-center/createMemberOrder/config.json

'use strict';

const jwt = require('jsonwebtoken');

// ---- 读取 JWT 配置 ----
let JWT_SECRET = '';
let JWT_EXPIRES_IN = '7d';

try {
  const createConfig = require('uni-config-center');
  const cfg = createConfig({ pluginId: 'createMemberOrder' });
  const config = cfg.config();

  if (config && config.jwt && config.jwt.secret) {
    JWT_SECRET = config.jwt.secret;
    JWT_EXPIRES_IN = config.jwt.expiresIn || '7d';
    console.log('[authHelper] 已通过 uni-config-center 读取 JWT 配置', {
      hasSecret: true,
      expiresIn: JWT_EXPIRES_IN
    });
  }
} catch (e) {
  console.warn('[authHelper] uni-config-center 读取失败:', e.message);
}

// 兜底：开发环境允许使用调试密钥，生产环境直接报错
if (!JWT_SECRET) {
  const isDev =
    process.env.NODE_ENV === 'development' ||
    process.env.UNI_CLOUD_HBUILDERX_DEBUG === 'true';

  if (!isDev) {
    throw new Error(
      '[authHelper] 生产环境缺少 JWT_SECRET。请在 cloudfunctions/common/uni-config-center/createMemberOrder/config.json 中配置 jwt.secret。'
    );
  }

  console.warn(
    '[authHelper] 开发环境未读取到 JWT_SECRET，暂时使用默认调试密钥。正式发布前请务必配置 uni-config-center。'
  );
  JWT_SECRET = 'PLEASE_REPLACE_WITH_STRONG_SECRET_FOR_DEVELOPMENT_ONLY';
}

console.log('[authHelper] JWT 配置已加载', {
  hasSecret: !!JWT_SECRET,
  expiresIn: JWT_EXPIRES_IN
});

/**
 * 签发 JWT token
 * @param {Object} payload token 载荷
 * @param {string} expiresIn 过期时间，默认使用配置值
 * @returns {string}
 */
function signToken(payload, expiresIn = JWT_EXPIRES_IN) {
  if (!JWT_SECRET) {
    throw new Error('[authHelper] JWT_SECRET 未配置，无法签发 token');
  }
  return jwt.sign(payload, JWT_SECRET, { expiresIn });
}

/**
 * 验证 token 并获取用户 ID
 * @param {Object} event 云函数事件对象
 * @returns {Object}
 */
function verifyToken(event) {
  let token =
    event.uniIdToken ||
    event.token ||
    event.authorization ||
    (event.headers && (event.headers.authorization || event.headers.Authorization));

  if (!token) {
    console.log('[authHelper] receive empty token, rejected');
    return {
      success: false,
      userId: null,
      error: '未登录，请先登录'
    };
  }

  console.log('[authHelper] verifyToken 收到 token:');
  console.log(' - token 前10位:', typeof token === 'string' ? token.substring(0, 10) : '未知');
  console.log(' - token 长度:', typeof token === 'string' ? token.length : 0);

  try {
    // 兼容 Bearer 和纯 token
    if (typeof token === 'string') {
      token = token.replace(/^Bearer\s+/i, '').trim();
    }
    const decoded = jwt.verify(token, JWT_SECRET);

    if (!decoded || !decoded.uid) {
      console.log(' - 解析 uid: 失败 (无 uid 字段)');
      return {
        success: false,
        userId: null,
        error: '登录状态无效'
      };
    }

    console.log(' - 解析 uid: 成功, uid=', decoded.uid);
    return {
      success: true,
      userId: decoded.uid,
      error: null
    };
  } catch (err) {
    console.log(' - 解析 uid: 失败');
    console.log('[authHelper] jwt.verify 失败:', err.name, err.message);

    if (err.name === 'TokenExpiredError') {
      return {
        success: false,
        userId: null,
        error: '登录状态已过期，请重新登录'
      };
    }

    if (err.name === 'JsonWebTokenError') {
      return {
        success: false,
        userId: null,
        error: '登录状态无效'
      };
    }

    return {
      success: false,
      userId: null,
      error: '验证登录状态时发生错误'
    };
  }
}

/**
 * 验证用户权限（确保用户只能操作自己的数据）
 * @param {Object} event 云函数事件对象
 * @param {string} targetUserId 目标用户 ID
 * @returns {Object}
 */
function verifyUserPermission(event, targetUserId = null) {
  const tokenResult = verifyToken(event);

  if (!tokenResult.success) {
    return tokenResult;
  }

  const authenticatedUserId = tokenResult.userId;

  if (targetUserId && targetUserId !== authenticatedUserId) {
    return {
      success: false,
      userId: authenticatedUserId,
      error: '无权访问该数据'
    };
  }

  return {
    success: true,
    userId: authenticatedUserId,
    error: null
  };
}

/**
 * 统一响应格式
 * @param {number} code 状态码
 * @param {string} message 消息
 * @param {*} data 数据
 * @returns {Object}
 */
function createResponse(code, message, data = null) {
  return {
    code,
    message,
    data
  };
}

module.exports = {
  signToken,
  verifyToken,
  verifyUserPermission,
  createResponse,
  JWT_SECRET,
  JWT_EXPIRES_IN
};
