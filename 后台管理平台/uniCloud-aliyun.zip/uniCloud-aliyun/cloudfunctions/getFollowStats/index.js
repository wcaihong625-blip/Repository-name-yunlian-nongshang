// 获取关注统计云函数（关注数和粉丝数）
// 调用方式：uniCloud.callFunction({ name: 'getFollowStats', data: { uniIdToken, token } })

'use strict';
const { verifyToken } = require('./common/authHelper');

exports.main = async (event, context) => {
  const db = uniCloud.database();
  const followsCollection = db.collection('user_follows');

  const res = (code, message, data) => {
    return { code, message, data: data || null };
  };

  try {
    // 统一获取token并校验
    const tokenResult = verifyToken(event);
    if (!tokenResult.success) {
      return res(401, tokenResult.error || '登录状态无效');
    }
    const userId = tokenResult.userId;

    // 并行查询关注数和粉丝数
    const [followingRes, followersRes] = await Promise.all([
      // 查询我关注的人数
      followsCollection.where({ follower_id: userId }).count(),
      // 查询关注我的人数
      followsCollection.where({ following_id: userId }).count()
    ]);

    const following = followingRes.total || 0;
    const followers = followersRes.total || 0;

    console.log(`用户 ${userId} 的关注统计: 关注 ${following} 人, 粉丝 ${followers} 人`);

    return res(200, '获取成功', {
      following: following,
      followers: followers
    });
  } catch (err) {
    console.error('getFollowStats error:', err);
    return res(500, '服务器内部错误', { error: err.message });
  }
};
