'use strict';

const uniID = require('uni-id-common');

function safeString(value) {
  return value === undefined || value === null ? '' : String(value).trim();
}

exports.main = async (event, context) => {
  const db = uniCloud.database();
  const _ = db.command;
  const uniIDIns = uniID.createInstance({ context });

  const token = safeString(event.uniIdToken || event.token || '');
  if (!token) {
    return { code: 401, message: '请先登录' };
  }

  let payload;
  try {
    payload = await uniIDIns.checkToken(token);
    if (!payload || (payload.code !== 0 && !payload.uid) || !payload.uid) {
      return { code: 401, message: '请先登录' };
    }
  } catch (e) {
    return { code: 401, message: '登录失效，请重新登录' };
  }

  const settleMonth = safeString(event.settle_month);
  const salesId = safeString(event.sales_id);
  const salesName = safeString(event.sales_name);
  const settleStatus = event.settle_status !== undefined ? parseInt(event.settle_status, 10) : null;
  const page = parseInt(event.page, 10) || 1;
  const pageSize = parseInt(event.pageSize, 10) || 20;

  try {
    const query = {};
    if (settleMonth) query.settle_month = settleMonth;
    if (salesId) query.sales_id = salesId;
    if (salesName) query.sales_name = new RegExp(salesName, 'i');
    if (!isNaN(settleStatus) && settleStatus !== null) query.settle_status = settleStatus;

    const countRes = await db.collection('sales_commission_settle').where(query).count();
    const total = countRes.total || 0;

    const listRes = await db.collection('sales_commission_settle')
      .where(query)
      .orderBy('created_at', 'desc')
      .skip((page - 1) * pageSize)
      .limit(pageSize)
      .get();

    return {
      code: 200,
      message: '获取成功',
      data: {
        list: listRes.data || [],
        total,
        page,
        pageSize
      }
    };
  } catch (e) {
    console.error('getCommissionSettleList error:', e);
    return { code: 500, message: e.message || '查询失败' };
  }
};
