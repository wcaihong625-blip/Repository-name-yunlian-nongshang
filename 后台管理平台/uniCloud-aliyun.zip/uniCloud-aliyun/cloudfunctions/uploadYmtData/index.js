'use strict';

const db = uniCloud.database();

exports.main = async (event, context) => {
  const body = JSON.parse(event.body || '{}');

  const { type, items } = body;

  if (!type || !['origin', 'wholesale','analysis'].includes(type)) {
    return { success: false, message: 'invalid type' };
  }

  if (!items || !Array.isArray(items)) {
    return { success: false, message: 'no items received' };
  }

  // 根据类型选择不同集合
 const collectionName =
   type === 'origin' ? 'ymt_origin_price' :
   type === 'wholesale' ? 'ymt_wholesale_price' :
   'ymt_analysis_text';

  const collection = db.collection(collectionName);

  // 批量写入
  const result = await collection.add(items);

  return {
    success: true,
    message: 'ok',
    type,
    count: items.length
  };
};
