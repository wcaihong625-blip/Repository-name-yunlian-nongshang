'use strict';

const { verifyToken } = require('./common/authHelper');

function safeString(value) {
  return value === undefined || value === null ? '' : String(value).trim();
}

function safeNumber(value) {
  return value === undefined || value === null || isNaN(value) ? 0 : Number(value);
}

exports.main = async (event, context) => {
  const db = uniCloud.database();
  

  const token = safeString(event.uniIdToken || event.token || '');
  if (!token) {
    return { code: 401, message: '请先登录' };
  }

  let payload;
  try {
    payload = await uniIDIns.checkToken(token);
    if (!payload || (payload.code !== 0 && !tokenResult.userId) || !tokenResult.userId) {
      return { code: 401, message: '请先登录' };
    }
  } catch (e) {
    return { code: 401, message: '登录失效，请重新登录' };
  }

  const settleMonth = safeString(event.settle_month);
  const salesId = safeString(event.sales_id);
  const salesName = safeString(event.sales_name);
  const settleStatus = event.settle_status !== undefined && event.settle_status !== null && event.settle_status !== '' ? parseInt(event.settle_status, 10) : null;

  try {
    const query = {};
    if (settleMonth) query.settle_month = settleMonth;
    if (salesId) query.sales_id = salesId;
    if (salesName) query.sales_name = new RegExp(salesName, 'i');
    if (!isNaN(settleStatus) && settleStatus !== null) query.settle_status = settleStatus;

    // Export max 5000 records at a time
    const listRes = await db.collection('sales_commission_settle')
      .where(query)
      .orderBy('created_at', 'desc')
      .limit(5000)
      .get();

    let list = listRes.data || [];
    
    // Format data
    list = list.map(item => {
      let statusText = '';
      if (item.settle_status === 0) statusText = '待结算';
      else if (item.settle_status === 1) statusText = '已结算';
      else if (item.settle_status === 2) statusText = '部分结算';
      else statusText = '未知';

      let createdAtStr = '';
      if (item.created_at) {
        const d = new Date(item.created_at);
        const pad = n => n < 10 ? '0' + n : n;
        createdAtStr = `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
      }

      return {
        settle_month: item.settle_month || '',
        sales_name: item.sales_name || '',
        order_count: safeNumber(item.order_count),
        first_open_count: safeNumber(item.first_open_count),
        renewal_count: safeNumber(item.renewal_count),
        first_open_amount: safeNumber(item.first_open_amount).toFixed(2),
        renewal_amount: safeNumber(item.renewal_amount).toFixed(2),
        first_open_commission: safeNumber(item.first_open_commission).toFixed(2),
        renewal_commission: safeNumber(item.renewal_commission).toFixed(2),
        commission_total: safeNumber(item.commission_total).toFixed(2),
        commission_paid: safeNumber(item.commission_paid).toFixed(2),
        commission_unpaid: safeNumber(item.commission_unpaid).toFixed(2),
        settle_status: item.settle_status,
        settle_status_text: statusText,
        created_at: createdAtStr
      };
    });

    const headers = [
      'settle_month',
      'sales_name',
      'order_count',
      'first_open_count',
      'renewal_count',
      'first_open_amount',
      'renewal_amount',
      'first_open_commission',
      'renewal_commission',
      'commission_total',
      'commission_paid',
      'commission_unpaid',
      'settle_status_text',
      'created_at'
    ];
    
    const headers_zh = [
      '结算月',
      '业务员',
      '总单数',
      '首开单数',
      '续费单数',
      '首开金额',
      '续费金额',
      '首开提成',
      '续费提成',
      '总提成',
      '已结算',
      '未结算',
      '状态',
      '生成时间'
    ];

    return {
      code: 200,
      message: '导出成功',
      data: {
        headers,
        headers_zh,
        list
      }
    };
  } catch (e) {
    console.error('exportCommissionSettleData error:', e);
    return { code: 500, message: e.message || '导出数据失败' };
  }
};
