const db = uniCloud.database()
const dbCmd = db.command

module.exports = {
  // 逻辑1：来源参数记录（前端进入时或注册时调用）
  async recordCustomerSource(params) {
    let { user_id, mobile, sales_id, channel_id, invite_code } = params
    
    // 如果没有user_id或mobile，直接返回
    if (!user_id && !mobile) {
        return { code: 400, message: '无效的用户信息' }
    }

    // 1. 归属判定收口
    let final_channel_id = '';
    let final_channel_name = '';
    let final_sales_id = '';
    let final_sales_name = '';

    if (channel_id) {
        let channelRes = await db.collection('sales_channel').doc(channel_id).get()
        if (channelRes.data && channelRes.data.length > 0) {
            const channel = channelRes.data[0];
            final_channel_id = channel._id;
            final_channel_name = channel.channel_name;
            final_sales_id = channel.sales_id;
            final_sales_name = channel.sales_name;
        }
    } else if (invite_code) {
        let channelRes = await db.collection('sales_channel').where({ invite_code: invite_code }).get()
        if (channelRes.data && channelRes.data.length > 0) {
            const channel = channelRes.data[0];
            final_channel_id = channel._id;
            final_channel_name = channel.channel_name;
            final_sales_id = channel.sales_id;
            final_sales_name = channel.sales_name;
        }
    }

    // 2. 尝试根据user_id查，没有再查mobile
    let query = {}
    if (user_id) query.user_id = user_id
    else if (mobile) query.mobile = mobile
    
    let customerRes = await db.collection('customer_profile').where(query).get()
    
    if (customerRes.data && customerRes.data.length > 0) {
        let customer = customerRes.data[0]
        // 只有尚未有归属的，才能更新渠道信息
        if (!customer.first_sales_id) {
            let updateData = {}
            if (final_channel_id) {
                updateData.source_channel_id = final_channel_id
                updateData.source_channel_name = final_channel_name
            }
            //首开归属人也顺便根据渠道反查写进去
            if (final_sales_id) {
                updateData.first_sales_id = final_sales_id
                updateData.first_sales_name = final_sales_name
                updateData.current_sales_id = final_sales_id
                updateData.current_sales_name = final_sales_name
            }
            if (mobile && !customer.mobile) {
                updateData.mobile = mobile
            }
            if (Object.keys(updateData).length > 0) {
                updateData.updated_at = Date.now()
                await db.collection('customer_profile').doc(customer._id).update(updateData)
            }
        }
    } else {
        // 创建待分配客户
        let newData = {
            user_id: user_id || '',
            mobile: mobile || '',
            customer_type: 0,
            member_status: 0,
            source_channel_id: final_channel_id || '',
            source_channel_name: final_channel_name || '',
            first_sales_id: final_sales_id || '',
            first_sales_name: final_sales_name || '',
            current_sales_id: final_sales_id || '',
            current_sales_name: final_sales_name || '',
            created_at: Date.now(),
            updated_at: Date.now()
        }
        await db.collection('customer_profile').add(newData)
    }
    
    return { code: 0, message: '记录成功' }
  },

  // 支付成功后的通知回调核心逻辑：判断首开续费、记录归属、提成计算
  async processMemberOrder(orderParams) {
    const { order_no, user_id, mobile, pay_amount, original_amount, discount_amount, member_days, pay_channel, source_type, pay_time, channel_id, invite_code } = orderParams

    if (!user_id && !mobile) {
        return { code: 400, message: '缺失用户信息' }
    }

    // 1. 归属判定收口
    let final_channel_id = '';
    let final_channel_name = '';
    let final_sales_id = '';
    let final_sales_name = '';
    let final_invite_code = '';

    if (channel_id) {
        let chRes = await db.collection('sales_channel').doc(channel_id).get()
        if (chRes.data && chRes.data.length > 0) {
            const channel = chRes.data[0];
            final_channel_id = channel._id;
            final_channel_name = channel.channel_name;
            final_sales_id = channel.sales_id;
            final_sales_name = channel.sales_name;
            final_invite_code = channel.invite_code;
        }
    } else if (invite_code) {
        let chRes = await db.collection('sales_channel').where({ invite_code: invite_code }).get()
        if (chRes.data && chRes.data.length > 0) {
            const channel = chRes.data[0];
            final_channel_id = channel._id;
            final_channel_name = channel.channel_name;
            final_sales_id = channel.sales_id;
            final_sales_name = channel.sales_name;
            final_invite_code = channel.invite_code;
        }
    }

    // 2. 获取客户画像
    let query = {}
    if (user_id) query.user_id = user_id
    if (mobile) query.mobile = mobile
    
    let customerRes = await db.collection('customer_profile').where(query).limit(1).get()
    let customer = customerRes.data && customerRes.data.length > 0 ? customerRes.data[0] : null
    
    if (!customer) {
        // 异常场景：无画像则临时创建
        let insertRes = await db.collection('customer_profile').add({
            user_id: user_id || '',
            mobile: mobile || '',
            customer_type: 0,
            member_status: 0,
            created_at: Date.now(),
            updated_at: Date.now()
        })
        customer = { _id: insertRes.id, user_id, mobile }
    }

    // 3. 判断首开 / 续费
    let historyOrders = await db.collection('member_order').where(dbCmd.and([
        dbCmd.or([
            { user_id: user_id || '------' },
            { mobile: mobile || '------' }
        ]),
        { order_status: 1 }
    ])).limit(1).get()

    let isFirstOpen = historyOrders.data.length === 0
    let order_type = isFirstOpen ? 1 : 2 
    let commission_type = isFirstOpen ? 'first_open' : 'renewal'

    let first_sales_id = customer.first_sales_id || ''
    let first_sales_name = customer.first_sales_name || ''
    let source_channel_id = customer.source_channel_id || ''
    let source_channel_name = customer.source_channel_name || ''
    let current_sales_id = customer.current_sales_id || ''
    let current_sales_name = customer.current_sales_name || ''

    if (isFirstOpen) {
        first_sales_id = final_sales_id || ''
        first_sales_name = final_sales_name || ''
        source_channel_id = final_channel_id || ''
        source_channel_name = final_channel_name || ''
        current_sales_id = final_sales_id || ''
        current_sales_name = final_sales_name || ''
    } else {
        // 续费：更新当前服务人，但不覆盖首开信息
        current_sales_id = final_sales_id || current_sales_id || ''
        current_sales_name = final_sales_name || current_sales_name || ''
    }

    // 4. 计算提成
    let commission_rate = 0
    let commission_amount = 0
    const this_order_sales_id = current_sales_id || final_sales_id

    if (this_order_sales_id) {
        let staffRes = await db.collection('sales_staff').doc(this_order_sales_id).get()
        if (staffRes.data && staffRes.data.length > 0) {
            let staff = staffRes.data[0]
            commission_rate = isFirstOpen ? (staff.base_commission_rate_first || 0) : (staff.base_commission_rate_renew || 0)
            if (pay_amount > 0) {
                commission_amount = parseFloat((pay_amount * commission_rate).toFixed(2))
            }
        }
    }

    // 5. 写入订单
    let orderData = {
        order_no: order_no || 'VIP' + Date.now(),
        user_id,
        customer_id: customer._id,
        mobile,
        order_type,
        order_status: 1,
        pay_amount,
        original_amount: original_amount || pay_amount,
        discount_amount: discount_amount || 0,
        member_days: member_days || 365,
        pay_time: pay_time || Date.now(),
        sales_id: this_order_sales_id,
        sales_name: isFirstOpen ? first_sales_name : current_sales_name,
        first_sales_id,
        first_sales_name,
        channel_id: isFirstOpen ? source_channel_id : (final_channel_id || source_channel_id),
        channel_name: isFirstOpen ? source_channel_name : (final_channel_name || source_channel_name),
        invite_code: final_invite_code || customer.invite_code || '',
        commission_type,
        commission_rate,
        commission_amount: commission_amount || 0,
        commission_status: 0,
        pay_channel: pay_channel || 'wechat',
        source_type: source_type || 'mini_program',
        created_at: Date.now(),
        updated_at: Date.now()
    }

    let orderInsertRes = await db.collection('member_order').add(orderData)

    // 6. 更新客户档案
    let updateCustomer = {
        member_status: 1,
        updated_at: Date.now()
    }
    if (isFirstOpen) {
        updateCustomer.first_sales_id = first_sales_id
        updateCustomer.first_sales_name = first_sales_name
        updateCustomer.source_channel_id = source_channel_id
        updateCustomer.source_channel_name = source_channel_name
        updateCustomer.current_sales_id = current_sales_id
        updateCustomer.current_sales_name = current_sales_name
        if (!customer.first_bind_time) updateCustomer.first_bind_time = Date.now()
        updateCustomer.member_first_open_time = Date.now()
    } else {
        updateCustomer.current_sales_id = current_sales_id
        updateCustomer.current_sales_name = current_sales_name
        updateCustomer.member_last_renew_time = Date.now()
    }

    await db.collection('customer_profile').doc(customer._id).update(updateCustomer)

    return { code: 0, message: '处理成功', data: { order_id: orderInsertRes.id, isFirstOpen, commission_amount } }
  }
}
