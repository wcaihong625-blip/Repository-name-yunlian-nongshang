'use strict';

const { verifyToken } = require('./common/authHelper');

function safeString(value) {
  return value === undefined || value === null ? '' : String(value).trim();
}

exports.main = async (event, context) => {
  const db = uniCloud.database();
  const _ = db.command;
  

  const token = safeString(event.uniIdToken || event.token || '');
  if (!token) {
    return { code: 401, message: '请先登录' };
  }

  let payload;
  try {
    payload = await uniIDIns.checkToken(token);
    if (!payload || (payload.code !== 0 && !tokenResult.userId) || !tokenResult.userId) {
      return { code: 401, message: '请先登录' };
    }
  } catch (e) {
    return { code: 401, message: '登录失效，请重新登录' };
  }

  const settleId = safeString(event.settle_id);
  const remark = safeString(event.remark);

  if (!settleId) {
    return { code: 400, message: '缺少参数 settle_id' };
  }

  try {
    const settleRes = await db.collection('sales_commission_settle').doc(settleId).get();
    const settleData = settleRes.data && settleRes.data.length ? settleRes.data[0] : null;

    if (!settleData) {
      return { code: 404, message: '结算单不存在' };
    }

    if (settleData.settle_status === 1) {
      return { code: 400, message: '该结算单已经结算，不可重复操作' };
    }

    const orderIds = settleData.order_ids || [];
    const nowDate = new Date();

    let updatedOrderCount = 0;
    if (orderIds.length > 0) {
      // 增加校验逻辑：核查需要更新的 order_ids 中到底还有哪几条还没结算
      const unSettledOrdersRes = await db.collection('member_order').where({
        _id: _.in(orderIds),
        commission_status: 0
      }).get();

      if (!unSettledOrdersRes.data || unSettledOrdersRes.data.length === 0) {
        return { code: 400, message: '当前结算单对应订单已被处理，无需重复结算' };
      }

      // 注意：这里更新必须保证只覆盖 commission_status 为 0 的订单
      const orderUpdateRes = await db.collection('member_order').where({
        _id: _.in(orderIds),
        commission_status: 0
      }).update({
        commission_status: 1,
        commission_settle_time: nowDate,
        updated_at: nowDate
      });
      // 取出实际更新的条数提供给返回数据
      updatedOrderCount = orderUpdateRes.updated || 0;
    }

    // 更新结算单主档
    const commissionTotal = Number(settleData.commission_total) || 0;
    
    await db.collection('sales_commission_settle').doc(settleId).update({
      commission_paid: commissionTotal,
      commission_unpaid: 0,
      settle_status: 1, // 1=已结算
      remark: remark || settleData.remark,
      updated_at: nowDate
    });

    return {
      code: 200,
      message: '结算成功',
      data: {
        settle_id: settleId,
        settle_status: 1,
        commission_paid: commissionTotal,
        commission_unpaid: 0,
        updated_order_count: updatedOrderCount
      }
    };
  } catch (e) {
    console.error('confirmCommissionSettle error:', e);
    return { code: 500, message: e.message || '结算失败，请稍后再试' };
  }
};
