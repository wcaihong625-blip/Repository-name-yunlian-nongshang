'use strict';

const db = uniCloud.database();
const prices = db.collection('prices');

exports.main = async (event, context) => {
  const items = event.items || [];

  if (!Array.isArray(items) || items.length === 0) {
    return { success: false, message: 'no items' };
  }

  const today = new Date().toISOString().slice(0, 10);

  for (const it of items) {
    const market = it.market || '';
    const product = it.product || '';
    const spec = it.spec || '';
    const price = it.price || '';
    const url = it.url || '';

    // 查是否已经存在（避免重复）
    const check = await prices.where({
      market,
      product,
      date: today
    }).get();

    const data = {
      market,
      product,
      spec,
      price,
      url,
      date: today,
      updated_at: new Date(),
    };

    if (check.data.length > 0) {
      await prices.doc(check.data[0]._id).update(data);
    } else {
      await prices.add(data);
    }
  }

  return { success: true, imported: items.length };
};
