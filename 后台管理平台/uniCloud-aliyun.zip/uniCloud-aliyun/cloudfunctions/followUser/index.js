// 关注用户云函数
// 调用方式：uniCloud.callFunction({ name: 'followUser', data: { token, following_id } })

'use strict';

const { verifyToken, createResponse } = require('./common/authHelper');

exports.main = async (event, context) => {
  const db = uniCloud.database();
  const followsCollection = db.collection('user_follows');
  const usersCollection = db.collection('uni-id-users');

  const res = createResponse;

  try {
    // 验证token并获取当前用户ID
    const authResult = verifyToken(event);
    if (!authResult.success) {
      return res(401, authResult.error);
    }

    const followerId = authResult.userId;
    const { following_id } = event;

    if (!following_id) {
      return res(400, '参数错误：following_id不能为空');
    }

    // 不能关注自己
    if (followerId === following_id) {
      return res(400, '不能关注自己');
    }

    // 检查被关注用户是否存在
    const userCheck = await usersCollection.doc(following_id).get();
    if (!userCheck.data || userCheck.data.length === 0) {
      return res(404, '被关注用户不存在');
    }

    // 检查是否已经关注
    const existingFollow = await followsCollection
      .where({
        follower_id: followerId,
        following_id: following_id
      })
      .count();

    if (existingFollow.total > 0) {
      return res(400, '您已经关注过该用户');
    }

    // 创建关注关系
    const now = new Date();
    await followsCollection.add({
      follower_id: followerId,
      following_id: following_id,
      created_date: now
    });

    console.log(`用户 ${followerId} 关注了用户 ${following_id}`);

    return res(200, '关注成功', {
      follower_id: followerId,
      following_id: following_id,
      created_date: now
    });
  } catch (err) {
    console.error('followUser error:', err);
    return res(500, '服务器内部错误', { error: err.message });
  }
};

