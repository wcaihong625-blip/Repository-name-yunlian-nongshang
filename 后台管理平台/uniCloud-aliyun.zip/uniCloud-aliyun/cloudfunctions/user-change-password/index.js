// 修改密码云函数（需登录态）
// 调用方式：uniCloud.callFunction({ name: 'user-change-password', data: { oldPassword, newPassword, token } })

/**
 * ----------------------------------------------------
 * 【废弃停用声明】（后台统一登录整理）
 * 本自定义云函数为历史遗留方案。
 * 当前后台管理平台（admin）已全面统一接入官方 `uni-id-co` + `uni-id-pages`。
 * 该文件不再作为主流链路的一部分，请勿继续使用或扩展，仅作代码存档隔离。
 * ----------------------------------------------------
 */
'use strict';

const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

// 必须与 user-login 中保持一致
const JWT_SECRET = 'PLEASE_REPLACE_WITH_STRONG_SECRET';

exports.main = async (event, context) => {
  const db = uniCloud.database();
  const usersCollection = db.collection('uni-id-users');

  const { oldPassword, newPassword, token } = event;

  const res = (code, message, data) => {
    return { code, message, data: data || null };
  };

  try {
    if (!token) {
      return res(401, '未登录');
    }

    if (!oldPassword || !newPassword) {
      return res(400, '参数错误：oldPassword 和 newPassword 为必填项');
    }

    if (typeof newPassword !== 'string' || newPassword.length < 6) {
      return res(400, '新密码格式不符合要求：长度需不小于6位');
    }

    let decoded;
    try {
      decoded = jwt.verify(token, JWT_SECRET);
    } catch (e) {
      return res(401, '登录状态无效或已过期');
    }

    const userId = decoded.uid;
    if (!userId) {
      return res(401, '登录状态无效');
    }

    // 查询当前用户
    const userRes = await usersCollection
      .doc(userId)
      .get();

    if (!userRes.data) {
      return res(400, '用户不存在');
    }

    const user = userRes.data;

    if (user.status !== 0) {
      return res(400, '账号已被禁用');
    }

    // 校验旧密码
    const matchOld = await bcrypt.compare(oldPassword, user.password);
    if (!matchOld) {
      return res(400, '旧密码错误');
    }

    // 加密新密码
    const newHash = await bcrypt.hash(newPassword, 10);

    // 更新密码，可选：同时增加 token_version 字段，让旧 token 失效
    await usersCollection
      .doc(userId)
      .update({
        password: newHash
      });

    return res(200, '密码修改成功');
  } catch (err) {
    console.error('user-change-password error:', err);
    return res(500, '服务器内部错误', { error: err.message });
  }
};

