// 获取用户信息云函数
// 调用方式：uniCloud.callFunction({ name: 'getUserInfo', data: { user_id } })

'use strict';

exports.main = async (event, context) => {
  const db = uniCloud.database();
  const usersCollection = db.collection('uni-id-users');

  const res = (code, message, data) => {
    return { code, message, data: data || null };
  };

  try {
    const { user_id } = event;

    if (!user_id) {
      return res(400, '参数错误：user_id不能为空');
    }

    console.log('getUserInfo 参数:', { user_id });

    // 查询用户信息
    const queryRes = await usersCollection.doc(user_id).get();

    if (!queryRes.data || queryRes.data.length === 0) {
      return res(404, '用户不存在');
    }

    const user = queryRes.data[0];

    // 格式化用户信息（只返回必要的公开信息）
    const formattedData = {
      user_id: user._id,
      username: user.username || '',
      nickname: user.nickname || user.username || '用户',
      mobile: user.mobile || '', // 电话信息
      avatar: user.avatar || '',
      location: user.location || '',
      industry: user.industry || '',
      bio: user.bio || '',
      isRealNameVerified: user.isRealNameVerified || false,
      isEnterpriseVerified: user.isEnterpriseVerified || false,
      companyName: user.companyName || ''
    };

    console.log('用户信息查询成功:', formattedData.user_id);

    return res(200, '获取成功', formattedData);
  } catch (err) {
    console.error('getUserInfo error:', err);
    return res(500, '服务器内部错误', { error: err.message });
  }
};



