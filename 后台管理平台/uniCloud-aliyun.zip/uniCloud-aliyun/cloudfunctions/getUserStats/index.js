// 获取用户统计数据云函数
// 调用方式：uniCloud.callFunction({ name: 'getUserStats', data: { user_id } })

'use strict';

exports.main = async (event, context) => {
  const db = uniCloud.database();
  const usersCollection = db.collection('uni-id-users');
  const supplyCollection = db.collection('supply_list');
  const purchaseCollection = db.collection('purchase_list');

  const res = (code, message, data) => {
    return { code, message, data: data || null };
  };

  try {
    const { user_id } = event;

    if (!user_id) {
      return res(400, '参数错误：user_id不能为空');
    }

    console.log('getUserStats 参数:', { user_id });

    // 查询用户信息（包含统计字段）
    const queryRes = await usersCollection.doc(user_id).get();

    if (!queryRes.data || queryRes.data.length === 0) {
      return res(404, '用户不存在');
    }

    const user = queryRes.data[0];

    // 从用户表获取统计字段
    let supplyCount = user.supply_count || 0;
    let procurementCount = user.procurement_count || 0;
    let views = user.profile_views || 0;

    // 如果用户表字段未更新，从实际数据表统计（作为备用）
    // 并行查询供应和采购数量
    const [supplyCountRes, procurementCountRes] = await Promise.all([
      supplyCollection.where({ user_id: user_id }).count().catch(() => ({ total: 0 })),
      purchaseCollection.where({ user_id: user_id }).count().catch(() => ({ total: 0 }))
    ]);

    // 如果用户表字段为0或不存在，使用实时统计的数据
    if (supplyCount === 0 && supplyCountRes.total > 0) {
      supplyCount = supplyCountRes.total;
    }
    if (procurementCount === 0 && procurementCountRes.total > 0) {
      procurementCount = procurementCountRes.total;
    }

    const statsData = {
      supply: supplyCount,
      procurement: procurementCount,
      views: views
    };

    console.log('用户统计数据查询成功:', { user_id, ...statsData });

    return res(200, '获取成功', statsData);
  } catch (err) {
    console.error('getUserStats error:', err);
    return res(500, '服务器内部错误', { error: err.message });
  }
};
















