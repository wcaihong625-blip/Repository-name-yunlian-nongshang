// 获取供应详情云函数
// 调用方式：uniCloud.callFunction({ name: 'getSupplyDetail', data: { id } })

'use strict';

exports.main = async (event, context) => {
  const db = uniCloud.database();
  const supplyCollection = db.collection('supply_list');

  const res = (code, message, data) => {
    return { code, message, data: data || null };
  };

  try {
    const { id } = event;

    if (!id) {
      return res(400, '参数错误：id不能为空');
    }

    console.log('getSupplyDetail 参数:', { id });

    // 查询供应详情
    const queryRes = await supplyCollection.doc(id).get();

    if (!queryRes.data || queryRes.data.length === 0) {
      return res(404, '供应信息不存在');
    }

    const item = queryRes.data[0];

    // 计算相对时间
    const timeAgo = getTimeAgo(item.created_date);

    // 格式化数据
    const formattedData = {
      id: item._id,
      title: item.title,
      category: item.category,
      specifications: item.specifications,
      quantity: item.quantity,
      unit: item.unit,
      price: item.price,
      location: item.location,
      imageUrl: item.images && item.images.length > 0 ? item.images[0] : '/static/images/default-product.png',
      images: item.images || [],
      description: item.description,
      publisher: item.publisher,
      user_id: item.user_id,
      status: item.status === '审核中' || item.status === '审核失败' ? '已发布' : item.status,
      time: timeAgo,
      updateTime: timeAgo,
      created_date: item.created_date,
      updated_date: item.updated_date
    };

    console.log('供应详情查询成功:', formattedData.id);

    return res(200, '获取成功', formattedData);
  } catch (err) {
    console.error('getSupplyDetail error:', err);
    return res(500, '服务器内部错误', { error: err.message });
  }
};

// 计算相对时间
function getTimeAgo(timestamp) {
  if (!timestamp) return '';
  
  const now = new Date();
  const time = timestamp instanceof Date ? timestamp : new Date(timestamp);
  const diff = now - time;
  
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);
  
  if (minutes < 1) {
    return '刚刚';
  } else if (minutes < 60) {
    return `${minutes}分钟前`;
  } else if (hours < 24) {
    return `${hours}小时前`;
  } else if (days < 30) {
    return `${days}天前`;
  } else {
    const year = time.getFullYear();
    const month = String(time.getMonth() + 1).padStart(2, '0');
    const day = String(time.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }
}



