// 用户登录云函数
// 调用方式：uniCloud.callFunction({ name: 'user-login', data: { account, password } })
// account 可以是用户名或手机号

/**
 * ----------------------------------------------------
 * 【废弃停用声明】（后台统一登录整理）
 * 本自定义登录云函数 (user-login) 为历史遗留的自研 JWT 方案。
 * 当前后台管理平台（admin）已全面统一接入官方 `uni-id-co` + `uni-id-pages`。
 * 该文件不再作为主登录链路的一部分，请勿继续使用或扩展，仅作代码存档隔离。
 * 设置或读取 JWT_SECRET、检查 token 的逻辑也请全部转移到:
 * uni_modules/uni-config-center/uniCloud/cloudfunctions/common/uni-config-center/uni-id/config.json
 * ----------------------------------------------------
 */
'use strict';

const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

// 生产环境请从环境变量或更安全的配置中读取
const JWT_SECRET = 'PLEASE_REPLACE_WITH_STRONG_SECRET';
const JWT_EXPIRES_IN = '7d';

exports.main = async (event, context) => {
  const db = uniCloud.database();
  const usersCollection = db.collection('uni-id-users');

  const { account, password } = event;

  const res = (code, message, data) => {
    return { code, message, data: data || null };
  };

  try {
    if (!account || !password) {
      return res(400, '参数错误：account 和 password 为必填项');
    }

    // 查询用户：用户名或手机号
    const userRes = await usersCollection
      .where({
        $or: [
          { username: account },
          { mobile: account }
        ]
      })
      .limit(1)
      .get();

    if (!userRes.data || userRes.data.length === 0) {
      return res(400, '用户不存在');
    }

    const user = userRes.data[0];

    // 账号状态校验
    if (user.status !== 0) {
      return res(400, '账号已被禁用');
    }

    // 密码验证
    const passwordMatch = await bcrypt.compare(password, user.password);
    if (!passwordMatch) {
      return res(400, '密码错误');
    }

    // 生成 token，包含用户基本标识
    const tokenPayload = {
      uid: user._id,
      username: user.username,
      mobile: user.mobile,
      status: user.status
    };

    const token = jwt.sign(tokenPayload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });

    // 更新最后登录时间
    await usersCollection
      .doc(user._id)
      .update({
        last_login_date: new Date()
      });

    return res(200, '登录成功', {
      token,
      user_id: user._id,
      nickname: user.nickname || '',
      avatar: user.avatar || '',
      username: user.username,
      mobile: user.mobile || ''
    });
  } catch (err) {
    console.error('user-login error:', err);
    return res(500, '服务器内部错误', { error: err.message });
  }
};

