// 审核实名认证云函数（供管理后台使用）
// 调用方式：uniCloud.callFunction({ name: 'auditRealnameAuth', data: { id: '...', action: 'approve/reject', auditor_id: '...', rejectReason: '...' } })

'use strict';

exports.main = async (event, context) => {
  const db = uniCloud.database();
  const authCollection = db.collection('realname_auth');
  const usersCollection = db.collection('uni-id-users');

  const res = (code, message, data) => {
    return { code, message, data: data || null };
  };

  try {
    const {
      id,
      action, // 'approve' 或 'reject'
      auditor_id,
      auditor_name,
      rejectReason = ''
    } = event;

    // 参数验证
    if (!id || !action || !auditor_id) {
      return res(400, '参数错误：id、action、auditor_id不能为空');
    }

    if (action !== 'approve' && action !== 'reject') {
      return res(400, '参数错误：action只能是approve或reject');
    }

    // 如果驳回，必须有驳回原因
    if (action === 'reject' && !rejectReason) {
      return res(400, '参数错误：驳回操作必须提供驳回原因');
    }

    // 查询认证记录
    const authRes = await authCollection.doc(id).get();
    if (!authRes.data || authRes.data.length === 0) {
      return res(400, '认证记录不存在');
    }

    const authRecord = authRes.data[0];

    // 只有待审核状态的记录才能审核
    if (authRecord.status !== 'pending') {
      return res(400, `该记录状态为${authRecord.status}，无法进行审核操作`);
    }

    // 获取审核人信息
    let auditorName = auditor_name || '';
    if (!auditorName) {
      const auditorRes = await usersCollection.doc(auditor_id).field({
        nickname: true,
        username: true
      }).get();
      if (auditorRes.data && auditorRes.data.length > 0) {
        auditorName = auditorRes.data[0].nickname || auditorRes.data[0].username || '管理员';
      }
    }

    const now = new Date();
    let updateData = {
      updated_date: now,
      audit_date: now,
      auditor_id: auditor_id,
      auditor_name: auditorName
    };

    // 根据操作类型更新状态
    if (action === 'approve') {
      // 通过审核
      updateData.status = 'verified';
      updateData.verified_date = now;
      updateData.rejectReason = '';

      // 检查该身份证号是否已被其他用户使用
      const idCardCheck = await authCollection.where({
        idCard: authRecord.idCard,
        status: 'verified',
        _id: db.command.neq(id)
      }).get();

      if (idCardCheck.data && idCardCheck.data.length > 0) {
        return res(400, '该身份证号已被其他用户认证使用');
      }
    } else {
      // 驳回审核
      updateData.status = 'rejected';
      updateData.rejectReason = rejectReason.trim();
      updateData.verified_date = null;
    }

    // 更新数据库
    const updateRes = await authCollection.doc(id).update(updateData);

    if (updateRes.updated > 0) {
      return res(200, action === 'approve' ? '审核通过' : '审核驳回', {
        id: id,
        status: updateData.status,
        audit_date: updateData.audit_date,
        auditor_id: auditor_id,
        auditor_name: auditorName,
        rejectReason: updateData.rejectReason || ''
      });
    } else {
      return res(500, '审核失败，请重试');
    }
  } catch (err) {
    console.error('auditRealnameAuth error:', err);
    return res(500, '服务器内部错误', { error: err.message });
  }
};

