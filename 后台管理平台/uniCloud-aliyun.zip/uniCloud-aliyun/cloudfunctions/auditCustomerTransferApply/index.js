'use strict';

const { verifyToken } = require('./common/authHelper');

function safeString(value) {
  return value === undefined || value === null ? '' : String(value).trim();
}

exports.main = async (event, context) => {
  const db = uniCloud.database();
  const _ = db.command;
  

  const token = safeString(event.uniIdToken || event.token || '');
  if (!token) {
    return { code: 401, message: '请先登录' };
  }

  let payload;
  try {
    payload = await uniIDIns.checkToken(token);
    if (!payload || (payload.code !== 0 && !tokenResult.userId) || !tokenResult.userId) {
      return { code: 401, message: '请先登录' };
    }
  } catch (e) {
    return { code: 401, message: '登录失效，请重新登录' };
  }

  const uid = tokenResult.userId;
  const applyId = safeString(event.apply_id);
  const auditAction = safeString(event.audit_action);
  const auditRemark = safeString(event.audit_remark);

  if (!applyId) {
    return { code: 400, message: '缺少 apply_id' };
  }
  if (auditAction !== 'approve' && auditAction !== 'reject') {
    return { code: 400, message: 'audit_action 必须为 approve 或 reject' };
  }

  try {
    // 1. 获取审批人信息
    const auditUserRes = await db.collection('uni-id-users').doc(uid).get();
    const auditUser = auditUserRes.data && auditUserRes.data.length ? auditUserRes.data[0] : {};
    const auditUserName = auditUser.nickname || auditUser.username || '';

    // 2. 查询申请表
    const applyRes = await db.collection('customer_transfer_apply').doc(applyId).get();
    const applyData = applyRes.data && applyRes.data.length ? applyRes.data[0] : null;

    if (!applyData) {
      return { code: 404, message: '该审批申请不存在' };
    }

    if (applyData.audit_status !== 0) {
      // 幂等：防止被重复审批
      return { code: 400, message: '该申请已审批，不可重复操作' };
    }

    // 3. 查询关联客户
    const customerId = applyData.customer_id;
    const customerRes = await db.collection('customer_profile').doc(customerId).get();
    const customerProfile = customerRes.data && customerRes.data.length ? customerRes.data[0] : null;

    if (!customerProfile) {
      return { code: 404, message: '关联客户不存在' };
    }

    const nowDate = new Date();
    const isApprove = auditAction === 'approve';
    const nextStatus = isApprove ? 1 : 2;

    const applyUpdateData = {
      audit_status: nextStatus,
      audit_user_id: uid,
      audit_user_name: auditUserName,
      audit_remark: auditRemark,
      audit_time: nowDate,
      updated_at: nowDate
    };

    if (isApprove) {
      applyUpdateData.effective_time = nowDate;
    }

    // 4. 更新申请记录
    await db.collection('customer_transfer_apply').doc(applyId).update(applyUpdateData);

    // 5. 更新 customer_profile
    let customerUpdateData = {};
    if (isApprove) {
      const currentCount = Number(customerProfile.transfer_count) || 0;
      customerUpdateData = {
        current_sales_id: applyData.new_sales_id,
        current_sales_name: applyData.new_sales_name,
        transfer_status: 0,
        transfer_count: currentCount + 1,
        updated_at: nowDate
      };
    } else {
      customerUpdateData = {
        transfer_status: 0,
        updated_at: nowDate
      };
    }

    await db.collection('customer_profile').doc(customerId).update(customerUpdateData);

    return {
      code: 200,
      message: isApprove ? '审批已通过' : '审批已拒绝',
      data: {
        apply_id: applyId,
        audit_status: nextStatus,
        customer_id: customerId,
        current_sales_id: isApprove ? applyData.new_sales_id : customerProfile.current_sales_id,
        current_sales_name: isApprove ? applyData.new_sales_name : customerProfile.current_sales_name
      }
    };

  } catch (e) {
    console.error('auditCustomerTransferApply error:', e);
    return { code: 500, message: e.message || '服务繁忙，请稍后再试' };
  }
};
