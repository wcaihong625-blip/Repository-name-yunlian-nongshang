// 获取我的关注列表云函数
// 调用方式：uniCloud.callFunction({ name: 'getMyFollows', data: { token, page, pageSize } })

'use strict';

const { verifyToken, createResponse } = require('./common/authHelper');

exports.main = async (event, context) => {
  const db = uniCloud.database();
  const followsCollection = db.collection('user_follows');
  const usersCollection = db.collection('uni-id-users');

  const res = createResponse;

  try {
    // 验证token并获取当前用户ID
    const authResult = verifyToken(event);
    if (!authResult.success) {
      return res(401, authResult.error);
    }

    const userId = authResult.userId;
    const page = event.page || 1;
    const pageSize = event.pageSize || 10;

    // 查询关注列表
    const followsRes = await followsCollection
      .where({
        follower_id: userId
      })
      .orderBy('created_date', 'desc')
      .skip((page - 1) * pageSize)
      .limit(pageSize)
      .get();

    // 获取总数
    const totalRes = await followsCollection
      .where({
        follower_id: userId
      })
      .count();

    const total = totalRes.total;
    const followingIds = followsRes.data.map(item => item.following_id);

    // 批量获取用户信息
    let usersData = [];
    if (followingIds.length > 0) {
      const usersRes = await usersCollection
        .where({
          _id: db.command.in(followingIds)
        })
        .get();

      // 创建用户ID到用户信息的映射
      const userMap = {};
      usersRes.data.forEach(user => {
        userMap[user._id] = {
          id: user._id,
          username: user.username || '',
          nickname: user.nickname || user.username || '用户',
          avatar: user.avatar || '',
          location: user.location || '',
          industry: user.industry || '',
          bio: user.bio || '',
          isRealNameVerified: user.isRealNameVerified || false,
          isEnterpriseVerified: user.isEnterpriseVerified || false,
          companyName: user.companyName || ''
        };
      });

      // 按照关注顺序排列用户信息
      usersData = followingIds.map(id => userMap[id]).filter(Boolean);

      // 为每个用户添加关注时间
      usersData.forEach((user, index) => {
        const followRecord = followsRes.data[index];
        user.followed_date = followRecord.created_date;
      });
    }

    return res(200, '获取成功', {
      data: usersData,
      total: total,
      page: page,
      pageSize: pageSize,
      hasMore: (page * pageSize) < total
    });
  } catch (err) {
    console.error('getMyFollows error:', err);
    return res(500, '服务器内部错误', { error: err.message });
  }
};

