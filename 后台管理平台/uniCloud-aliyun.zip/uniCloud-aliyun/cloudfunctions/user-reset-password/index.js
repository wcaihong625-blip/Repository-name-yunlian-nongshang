// 忘记密码/重置密码云函数（通过手机号和验证码）
// 调用方式：uniCloud.callFunction({ name: 'user-reset-password', data: { mobile, code, newPassword } })
// 注意：实际项目中应该先验证验证码（通过短信服务），这里简化处理

/**
 * ----------------------------------------------------
 * 【废弃停用声明】（后台统一登录整理）
 * 本自定义云函数为历史遗留方案。
 * 当前后台管理平台（admin）已全面统一接入官方 `uni-id-co` + `uni-id-pages`。
 * 该文件不再作为主流链路的一部分，请勿继续使用或扩展，仅作代码存档隔离。
 * ----------------------------------------------------
 */
'use strict';

const bcrypt = require('bcryptjs');

// 生产环境请从环境变量或安全配置中读取
const SALT_ROUNDS = 10;

exports.main = async (event, context) => {
  const db = uniCloud.database();
  const usersCollection = db.collection('uni-id-users');

  const { mobile, code, newPassword } = event;

  // 统一返回方法
  const res = (code, message, data) => {
    return { code, message, data: data || null };
  };

  try {
    // 参数校验
    if (!mobile || !code || !newPassword) {
      return res(400, '参数错误：mobile、code 和 newPassword 为必填项');
    }

    // 手机号格式校验
    const mobileReg = /^1[3-9]\d{9}$/;
    if (!mobileReg.test(mobile)) {
      return res(400, '手机号格式错误');
    }

    // 密码强度校验
    if (typeof newPassword !== 'string' || newPassword.length < 6) {
      return res(400, '新密码格式不符合要求：长度需不小于6位');
    }

    // TODO: 实际项目中应该验证验证码（通过短信服务或Redis等）
    // 这里简化处理，验证码为 '123456' 时通过（仅用于开发测试）
    if (code !== '123456') {
      return res(400, '验证码错误');
    }

    // 查询用户
    const userRes = await usersCollection
      .where({ mobile })
      .limit(1)
      .get();

    if (!userRes.data || userRes.data.length === 0) {
      return res(400, '该手机号未注册');
    }

    const user = userRes.data[0];

    if (user.status !== 0) {
      return res(400, '账号已被禁用');
    }

    // 加密新密码
    const newHash = await bcrypt.hash(newPassword, SALT_ROUNDS);

    // 更新密码
    await usersCollection
      .doc(user._id)
      .update({
        password: newHash
      });

    return res(200, '密码重置成功');
  } catch (err) {
    console.error('user-reset-password error:', err);
    return res(500, '服务器内部错误', { error: err.message });
  }
};

