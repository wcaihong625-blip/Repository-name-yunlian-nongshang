'use strict';

const PasswordUtils = require('../uni-id-co/lib/utils/password');
const uniIdConfig = require('uni-config-center/uni-id/config.json');

const TARGET_USERNAME = 'nxt';
const CONFIRM_CODE = 'RESET_NXT_ADMIN_PASSWORD';
const TARGET_NEW_PASSWORD = 'nxt619619';

exports.main = async (event = {}) => {
  const { confirm } = event;

  if (confirm !== CONFIRM_CODE) {
    return {
      errCode: 'INVALID_CONFIRM_CODE',
      errMsg: '确认码不正确，拒绝执行临时重置'
    };
  }

  const db = uniCloud.database();
  const usersCollection = db.collection('uni-id-users');
  const userRes = await usersCollection.where({
    username: TARGET_USERNAME
  }).limit(2).get();

  const userList = userRes.data || [];
  if (userList.length !== 1) {
    return {
      errCode: 'TARGET_USER_NOT_UNIQUE',
      errMsg: `目标账号 ${TARGET_USERNAME} 不存在或不唯一`
    };
  }

  const targetUser = userList[0];
  const roleList = Array.isArray(targetUser.role) ? targetUser.role : [];
  if (!roleList.includes('admin')) {
    return {
      errCode: 'TARGET_USER_ROLE_INVALID',
      errMsg: `目标账号 ${TARGET_USERNAME} 不是 admin 管理员`
    };
  }

  const passwordUtils = new PasswordUtils({
    clientInfo: {
      appId: '__temp-reset__',
      uniPlatform: 'web'
    },
    passwordSecret: uniIdConfig.passwordSecret
  });

  const { passwordHash, version } = passwordUtils.generatePasswordHash({
    password: TARGET_NEW_PASSWORD
  });

  await usersCollection.doc(targetUser._id).update({
    password: passwordHash,
    password_secret_version: version,
    valid_token_date: Date.now(),
    login_ip_limit: []
  });

  return {
    errCode: 0,
    errMsg: '',
    username: TARGET_USERNAME,
    updated: true,
    loginRetryLimitCleared: true,
    newPasswordPreset: true,
    shouldDeleteFunctionAfterUse: true
  };
};
